-- Group [Group]
create table "APP"."GROUP" (
   "OID"  integer  not null,
   "GROUPNAME"  varchar(255),
  primary key ("OID")
);


-- Module [Module]
create table "APP"."MODULE" (
   "OID"  integer  not null,
   "MODULEID"  varchar(255),
   "MODULENAME"  varchar(255),
  primary key ("OID")
);


-- User [User]
create table "APP"."USER" (
   "OID"  integer  not null,
   "USERNAME"  varchar(255),
   "PASSWORD"  varchar(255),
   "EMAIL"  varchar(255),
  primary key ("OID")
);


-- Utilizador [ent1]
create table "APP"."UTILIZADOR" (
   "COD_USER"  integer  not null,
   "NOME"  varchar(255),
   "PASSWORD"  varchar(255),
   "EMAIL"  varchar(255),
   "NIVEL_ACESSO"  integer,
   "DESACTIVADO"  smallint,
   "USERNAME"  varchar(255),
  primary key ("COD_USER")
);


-- Tarefas [ent2]
create table "APP"."TAREFAS" (
   "COD_TAREFA"  integer  not null,
   "NOME"  varchar(255),
   "LOCAL"  varchar(255),
   "DATA_TAREFA"  date,
   "PRIORIDADE"  integer,
   "INTERVENIENTES"  varchar(255),
   "URL"  varchar(255),
   "CONCLUIDA"  smallint,
   "COD_UTILIZADOR"  integer,
   "COD_CATEGORIA"  integer,
  primary key ("COD_TAREFA")
);


-- Categoria [ent3]
create table "APP"."CATEGORIA" (
   "COD_CATEGORIA"  integer  not null,
   "DESCRICAO"  varchar(255),
  primary key ("COD_CATEGORIA")
);


-- Reclamacao [ent4]
create table "APP"."RECLAMACAO" (
   "COD_RECLAMACAO"  integer  not null,
   "COD_USER"  integer,
   "TITULO"  varchar(255),
   "MENSAGEM"  varchar(255),
   "JA_VISTA"  smallint,
  primary key ("COD_RECLAMACAO")
);


-- Sugestao [ent5]
create table "APP"."SUGESTAO" (
   "COD_SUGESTAO"  integer  not null,
   "COD_USER"  integer,
   "TITULO"  varchar(255),
   "MENSAGEM"  varchar(255),
   "JA_VISTA"  smallint,
  primary key ("COD_SUGESTAO")
);


-- Subtarefa [ent6]
create table "APP"."SUBTAREFA" (
   "COD_SUBTAREFA"  integer  not null,
   "COD_TAREFA"  integer,
   "NOME"  varchar(255),
  primary key ("COD_SUBTAREFA")
);


-- Group_DefaultModule [Group2DefaultModule_DefaultModule2Group]
alter table "APP"."GROUP"  add column  "MODULE_OID"  integer;
alter table "APP"."GROUP"   add constraint FK_GROUP_MODULE foreign key ("MODULE_OID") references "APP"."MODULE" ("OID");


-- Group_Module [Group2Module_Module2Group]
create table "APP"."GROUP_MODULE" (
   "GROUP_OID"  integer not null,
   "MODULE_OID"  integer not null,
  primary key ("GROUP_OID", "MODULE_OID")
);
alter table "APP"."GROUP_MODULE"   add constraint FK_GROUP_MODULE_GROUP foreign key ("GROUP_OID") references "APP"."GROUP" ("OID");
alter table "APP"."GROUP_MODULE"   add constraint FK_GROUP_MODULE_MODULE foreign key ("MODULE_OID") references "APP"."MODULE" ("OID");


-- User_DefaultGroup [User2DefaultGroup_DefaultGroup2User]
alter table "APP"."USER"  add column  "GROUP_OID"  integer;
alter table "APP"."USER"   add constraint FK_USER_GROUP foreign key ("GROUP_OID") references "APP"."GROUP" ("OID");


-- User_Group [User2Group_Group2User]
create table "APP"."USER_GROUP" (
   "USER_OID"  integer not null,
   "GROUP_OID"  integer not null,
  primary key ("USER_OID", "GROUP_OID")
);
alter table "APP"."USER_GROUP"   add constraint FK_USER_GROUP_USER foreign key ("USER_OID") references "APP"."USER" ("OID");
alter table "APP"."USER_GROUP"   add constraint FK_USER_GROUP_GROUP foreign key ("GROUP_OID") references "APP"."GROUP" ("OID");


-- Utilizador_Reclamacao [rel1]
alter table "APP"."UTILIZADOR"  add column  "RECLAMACAO_COD_RECLAMACAO"  integer;
alter table "APP"."UTILIZADOR"   add constraint FK_UTILIZADOR_RECLAMACAO foreign key ("RECLAMACAO_COD_RECLAMACAO") references "APP"."RECLAMACAO" ("COD_RECLAMACAO");


-- Utilizador_Sugestao [rel2]
alter table "APP"."UTILIZADOR"  add column  "SUGESTAO_COD_SUGESTAO"  integer;
alter table "APP"."UTILIZADOR"   add constraint FK_UTILIZADOR_SUGESTAO foreign key ("SUGESTAO_COD_SUGESTAO") references "APP"."SUGESTAO" ("COD_SUGESTAO");


-- Utilizador_Tarefas [rel3]
alter table "APP"."UTILIZADOR"  add column  "TAREFAS_COD_TAREFA"  integer;
alter table "APP"."UTILIZADOR"   add constraint FK_UTILIZADOR_TAREFAS foreign key ("TAREFAS_COD_TAREFA") references "APP"."TAREFAS" ("COD_TAREFA");


-- Tarefas_Categoria [rel4]
alter table "APP"."CATEGORIA"  add column  "TAREFAS_COD_TAREFA"  integer;
alter table "APP"."CATEGORIA"   add constraint FK_CATEGORIA_TAREFAS foreign key ("TAREFAS_COD_TAREFA") references "APP"."TAREFAS" ("COD_TAREFA");


-- Tarefas_Subtarefa [rel5]
alter table "APP"."TAREFAS"  add column  "SUBTAREFA_COD_SUBTAREFA"  integer;
alter table "APP"."TAREFAS"   add constraint FK_TAREFAS_SUBTAREFA foreign key ("SUBTAREFA_COD_SUBTAREFA") references "APP"."SUBTAREFA" ("COD_SUBTAREFA");


-- Subtarefa_Subtarefa [rel6]
alter table "APP"."SUBTAREFA"  add column  "SUBTAREFA_COD_SUBTAREFA"  integer;
alter table "APP"."SUBTAREFA"   add constraint FK_SUBTAREFA_SUBTAREFA foreign key ("SUBTAREFA_COD_SUBTAREFA") references "APP"."SUBTAREFA" ("COD_SUBTAREFA");


