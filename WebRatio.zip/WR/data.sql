-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 18-Jan-2012 às 21:36
-- Versão do servidor: 5.1.44
-- versão do PHP: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `data`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `cod_categoria` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cod_categoria`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`cod_categoria`, `descricao`) VALUES
(1, 'Pessoal'),
(2, 'Trabalho');

-- --------------------------------------------------------

--
-- Estrutura da tabela `group`
--

CREATE TABLE IF NOT EXISTS `group` (
  `oid` int(11) NOT NULL,
  `groupname` varchar(255) DEFAULT NULL,
  `module_oid` int(11) DEFAULT NULL,
  PRIMARY KEY (`oid`),
  KEY `fk_group_module` (`module_oid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `group`
--

INSERT INTO `group` (`oid`, `groupname`, `module_oid`) VALUES
(1, 'admin', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `group_module`
--

CREATE TABLE IF NOT EXISTS `group_module` (
  `group_oid` int(11) NOT NULL,
  `module_oid` int(11) NOT NULL,
  PRIMARY KEY (`group_oid`,`module_oid`),
  KEY `fk_group_module_group` (`group_oid`),
  KEY `fk_group_module_module` (`module_oid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `group_module`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `module`
--

CREATE TABLE IF NOT EXISTS `module` (
  `oid` int(11) NOT NULL,
  `moduleid` varchar(255) DEFAULT NULL,
  `modulename` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`oid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `module`
--

INSERT INTO `module` (`oid`, `moduleid`, `modulename`) VALUES
(0, 'sv2', 'admin'),
(1, 'sv2', 'admin');

-- --------------------------------------------------------

--
-- Estrutura da tabela `prioridade`
--

CREATE TABLE IF NOT EXISTS `prioridade` (
  `cod_prioridade` int(11) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`cod_prioridade`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `prioridade`
--

INSERT INTO `prioridade` (`cod_prioridade`, `descricao`) VALUES
(1, 'Pouco Importante'),
(2, 'Importante'),
(3, 'Muito Imporante');

-- --------------------------------------------------------

--
-- Estrutura da tabela `reclamacao`
--

CREATE TABLE IF NOT EXISTS `reclamacao` (
  `cod_reclamacao` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `mensagem` varchar(255) DEFAULT NULL,
  `ja_vista` bit(1) DEFAULT NULL,
  `user_cod_utilizador` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_reclamacao`),
  KEY `fk_reclamacao_user` (`user_cod_utilizador`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `reclamacao`
--

INSERT INTO `reclamacao` (`cod_reclamacao`, `titulo`, `mensagem`, `ja_vista`, `user_cod_utilizador`) VALUES
(2, 'Reclamacao', 'Tenho uma reclamacao a fazer', '', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sugestao`
--

CREATE TABLE IF NOT EXISTS `sugestao` (
  `cod_sugestao` int(11) NOT NULL,
  `titulo` varchar(255) DEFAULT NULL,
  `mensagem` varchar(255) DEFAULT NULL,
  `ja_vista` bit(1) DEFAULT NULL,
  `user_cod_utilizador` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_sugestao`),
  KEY `fk_sugestao_user` (`user_cod_utilizador`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `sugestao`
--

INSERT INTO `sugestao` (`cod_sugestao`, `titulo`, `mensagem`, `ja_vista`, `user_cod_utilizador`) VALUES
(2, 'Ola', 'Imagens!', '', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `tarefas`
--

CREATE TABLE IF NOT EXISTS `tarefas` (
  `cod_tarefa` int(11) NOT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `local` varchar(255) DEFAULT NULL,
  `data_tarefa` date DEFAULT NULL,
  `intervenientes` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `concluida` bit(1) DEFAULT NULL,
  `prioridade_cod_prioridade` int(11) DEFAULT NULL,
  `categoria_cod_categoria` int(11) DEFAULT NULL,
  `user_cod_utilizador` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_tarefa`),
  KEY `fk_tarefas_prioridade` (`prioridade_cod_prioridade`),
  KEY `fk_tarefas_categoria` (`categoria_cod_categoria`),
  KEY `fk_tarefas_user` (`user_cod_utilizador`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `tarefas`
--

INSERT INTO `tarefas` (`cod_tarefa`, `nome`, `local`, `data_tarefa`, `intervenientes`, `url`, `concluida`, `prioridade_cod_prioridade`, `categoria_cod_categoria`, `user_cod_utilizador`) VALUES
(2, 'Ola mundo!!!!', '', '2012-01-31', '', '', '\0', 2, 1, 2),
(1, 'Eng Web', 'UM', '2012-01-18', 'Andreia e Andre', '', '', 3, 2, 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `cod_utilizador` int(11) NOT NULL,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nome` varchar(255) DEFAULT NULL,
  `nivel_acesso` int(11) DEFAULT NULL,
  `desactivado` bit(1) DEFAULT NULL,
  `group_oid` int(11) DEFAULT NULL,
  PRIMARY KEY (`cod_utilizador`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_user_group` (`group_oid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `user`
--

INSERT INTO `user` (`cod_utilizador`, `username`, `password`, `email`, `nome`, `nivel_acesso`, `desactivado`, `group_oid`) VALUES
(1, 'admin', 'administrador', 'admin@admin.com', 'administrador', NULL, NULL, 1),
(2, 'anaisabel', 'anaisabel', 'ana@a.com', 'Ana', NULL, NULL, NULL),
(3, 'andreia', 'andreia', 'and@a.com', 'Andreia', NULL, NULL, NULL),
(4, 'andre', 'andre', 'andre@a.com', 'andre', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_group`
--

CREATE TABLE IF NOT EXISTS `user_group` (
  `user_cod_utilizador` int(11) NOT NULL,
  `group_oid` int(11) NOT NULL,
  PRIMARY KEY (`user_cod_utilizador`,`group_oid`),
  KEY `fk_user_group_user` (`user_cod_utilizador`),
  KEY `fk_user_group_group` (`group_oid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `user_group`
--

