<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 2) header('Location: ./index.php');

$_SESSION['pageid']=9;

$lista_categorias = $_SESSION['agenda']->getListaCategorias();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
	  
		<div id="headercontainer"> 	
			<div id="banner"> </div>
				
				<div id="navbuttonsadmin">
					<a class="navbuttonadmin" href="admin_users.php">Users</a>
					<a style="text-decoration:underline" class="navbuttonadmin" href="admin_categories.php">Categories</a>
					<a class="navbuttonadmin" href="admin_sugestions.php">Suggestions</a>
					<a class="navbuttonadmin" href="admin_reclamations.php">Complaints</a>
					<a class="navbuttonadmin" href="settings.php">Settings</a>
					<a id="botao_logout" class="navbuttonadmin" href="scripts/logout.php">Logout</a>
				</div>
		
		</div>

		<div id="colunaesquerda">
			<div id="verticalnavbuttonsadmin">
			</div>
		</div>

		<div id="colunacentro">
			<div id="formcategoriacontainer">
			<h4>Add Category</h4>
			<p>&nbsp;</p>
			<form id="formcategoria" action="scripts/operacao_admin.php?op=4" method="post">
					  <span class="style1">Category:</span> 
			  <input name="categoria" type="text" size="30"/>
					<input type="submit" value="Add" />
			  </form>
			</div>
			<div id="listacategorias">
				<table id="tabcategorias" cellspacing="0">
				<h3 id="titulo" align="left">Categories List<br />
				  <br />
				</h3>
				
					<thead id="cabecalho_lista_categorias">
						<tr><td class="style1" id="cabecalho_descricao">Description</td>
						</tr>
					</thead>
					<tbody>
					
						<?php
						if(!isset($lista_categorias))
							echo "<tr><td>There are no categories registered.</tr></td>";
						else
						{
							foreach($lista_categorias as $categoria)
								echo '<tr class="linha_categoria"><td>' . $categoria['descricao'] . '</td>';
						}
						?>
					</tbody>
				</table>
					
			</div>
		</div>
		<div id="colunadireita">
		</div>
		<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div> 
	</div>
</body>
</html>
