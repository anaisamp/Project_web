<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()|| !isset($_GET['op']) || !isset($_GET['id'])) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 2) header('Location: ./index.php');

$_SESSION['pageid']=12;

if($_GET['op'] == 1)
{
$titulo = $_SESSION['agenda']->getTituloSugestao($_GET['id']);
$mensagem = $_SESSION['agenda']->getMensagemSugestao($_GET['id']);
$nome_utilizador = $_SESSION['agenda']->getNomeUtilizadorSugestao($_GET['id']);
$email_utilizador = $_SESSION['agenda']->getEmailUtilizadorSugestao($_GET['id']);
$op = 7;
}
elseif($_GET['op'] == 2)
{
$titulo = $_SESSION['agenda']->getTituloReclamacao($_GET['id']);
$mensagem = $_SESSION['agenda']->getMensagemReclamacao($_GET['id']);
$nome_utilizador = $_SESSION['agenda']->getNomeUtilizadorReclamacao($_GET['id']);
$email_utilizador = $_SESSION['agenda']->getEmailUtilizadorReclamacao($_GET['id']);
$op=8;
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
<style type="text/css">
<!--
.style9 {font-size: 14px}
.style11 {font-size: 14px; color: #224835; }
.style12 {color: #224835}
-->
</style>
</head>

<body>
	<div id="corpo">
	  
		<div id="headercontainer">
			<div id="banner"> </div>

				<div id="navbuttonsadmin">
					<a class="navbuttonadmin" href="admin_users.php">Users</a>
					<a class="navbuttonadmin" href="admin_categories.php">Categories</a>
					<a class="navbuttonadmin" href="admin_sugestions.php">Suggestions</a>
					<a class="navbuttonadmin" href="admin_reclamations.php">Complaints</a>
					<a class="navbuttonadmin" href="settings.php">Settings</a>
					<a id="botao_logout" class="navbuttonadmin" href="scripts/logout.php">Logout</a>
				</div>
			
		</div>

		<div id="colunaesquerda">
		</div>
	  <div id="colunacentro">
		
	    <div id="detalhes_mensagem">
				<h3>Message Details</h3>
				<p>&nbsp;</p>
				<p>&nbsp;</p>
				<p>	<span class="style11">Name:</span><span class="style1"> <?php echo $nome_utilizador ?> </span></p>
				<p><span class="maillink style9 style12">E-mail:</span><span class="style1"><?php echo ' <a class="maillink" href="mailto:' . $email_utilizador . '?Subject=RE: ' . $titulo . '&body=----- Original Message -----%0A' . $mensagem .' ">' . $email_utilizador . '</a><br />';?><br />
		  </span></p>
			  	<p class="style1">&nbsp;</p>
				<p><span class="maillink style9 style12">Title:</span><span class="style1"> <?php echo $titulo ?> <br />
		  </span></p>
				<p><span class="maillink style9 style12">Message:</span><span class="style1"> <?php echo $mensagem ?> <br />
		  </span></p>
		        <p>&nbsp;</p>
		        <p>&nbsp;</p>
                <div align="right"><?php echo '<a id="new_task_button" href="scripts/operacao_admin.php?op=' . $op . '&id=' . $_GET['id'] . '">Close</a>'; ?></div>
	    </div>
	    </p>
		</div>
		<div id="colunadireita">
		</div>
		<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div> 
	</div>
</body>
</html>
