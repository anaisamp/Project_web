<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 2) header('Location: ./index.php');

$_SESSION['pageid']=11;

$lista_reclamacoes = $_SESSION['agenda']->getListaReclamacoes();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
	  
		<div id="headercontainer">
			<div id="banner"> </div>
	
				<div id="navbuttonsadmin">
					<a class="navbutton" href="admin_users.php">Users</a>
					<a class="navbutton" href="admin_categories.php">Categories</a>
					<a class="navbutton" href="admin_sugestions.php">Suggestions</a>
					<a style="text-decoration:underline" class="navbutton" href="admin_reclamations.php">Complaints</a>
					<a class="navbutton" href="settings.php">Settings</a>
					<a id="botao_logout" class="navbutton" href="scripts/logout.php">Logout</a>
				</div>
			
		</div>

		<div id="colunaesquerda">
		</div>
		<div id="colunacentro">
			<div id="lista_sugestoes_reclamacoes">
				<table id="tab_sugestoes_reclamacoes" cellspacing="0">
				<h3 id="titulo" align="left">Complaints List<br />
				  <br />
				  <br />
				</h3>
					<thead id="cabecalho_lista_sugestoes_reclamacoes">

						<tr><td class="style1" id="cabecalho_titulo">Title</td>
						<td class="style1" id="cabecalho_nome">Name</td>
						<td class="colunabranco"></td></tr>
					</thead>
					<tbody>
					
						<?php
						if(!isset($lista_reclamacoes))
							echo "<tr><td>There are no reclamations received.</tr></td>";
						else
						{
							foreach($lista_reclamacoes as $reclamacao)
							{
								
								if(!$_SESSION['agenda']->reclamacaoJaLida($reclamacao['cod_reclamacao']))
									$estilo_linha = "linha_normal";
								else
									$estilo_linha = "linha_ja_lida";
									
								echo '<tr class="' . $estilo_linha . '"><td class="primeira_celula"><a href="admin_messagedetails.php?id=' .$reclamacao['cod_reclamacao'] .'&op=2">'. $reclamacao['titulo'] . '</a></td><td><a href="admin_messagedetails.php?id=' .$reclamacao['cod_reclamacao'] .'&op=2">' . $_SESSION['agenda']->getNomeUtilizadorCod($reclamacao['user_cod_utilizador']) . '</a></td><td><a style="text-decoration:underline" href="scripts/operacao_admin.php?op=6&id='. $reclamacao['cod_reclamacao'].'"> Delete </a></td></tr>';
							}
						}
						?>
					</tbody>
			  </table>
					
			</div>
		</div>
		<div id="colunadireita">
		</div>
		<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div> 
	</div>
</body>
</html>
