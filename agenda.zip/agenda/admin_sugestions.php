<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 2) header('Location: ./index.php');

$_SESSION['pageid']=10;

$lista_sugestoes = $_SESSION['agenda']->getListaSugestoes();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
	  
		<div id="headercontainer">
			<div id="banner"> </div>
	
				<div id="navbuttonsadmin">
					<a  href="admin_users.php">Users</a>
					<a  href="admin_categories.php">Categories</a>
					<a  href="admin_sugestions.php" style="text-decoration:underline"> Suggestions</a>
					<a  href="admin_reclamations.php">Complaints</a>
					<a  href="settings.php">Settings</a>
					<a id="botao_logout" class="navbutton" href="scripts/logout.php">Logout</a>				</div>
			
		</div>

		<div id="colunaesquerda">
		</div>
		<div id="colunacentro">
			<div id="lista_sugestoes_reclamacoes">
				<table id="tab_sugestoes_reclamacoes" cellspacing="0">
				<h3 id="titulo" align="left">Suggestions List<br />
				  <br />
				  <br />
				</h3>
					<thead id="cabecalho_lista_sugestoes_reclamacoes">

						<tr><td class="style1" id="cabecalho_titulo">Title</td>
						<td class="style1" id="cabecalho_nome">Name</td>
						<td class="colunabranco"></td></tr>
					</thead >
					<tbody>
					
						<?php
						if(!isset($lista_sugestoes))
							echo "<tr><td>There are no sugestions received.</tr></td>";
						else
						{
							foreach($lista_sugestoes as $sugestao)
							{
								
								if(!$_SESSION['agenda']->sugestaoJaLida($sugestao['cod_sugestao']))
									$estilo_linha = "linha_normal";
								else
									$estilo_linha = "linha_ja_lida";
									
								echo '<tr class="' . $estilo_linha . '"><td class="primeira_celula"><a href="admin_messagedetails.php?id=' .$sugestao['cod_sugestao'] .'&op=1">'. $sugestao['titulo'] . '</a></td><td><a href="admin_messagedetails.php?id=' .$sugestao['cod_sugestao'] .'&op=1">' . $_SESSION['agenda']->getNomeUtilizadorCod($sugestao['user_cod_utilizador']) . '</a></td><td><a style="text-decoration:underline" href="scripts/operacao_admin.php?op=5&id='. $sugestao['cod_sugestao'].'"> Delete </a></td></tr>';
							}
						}
						?>
					</tbody>
			  </table>					
			</div>
		</div>
		<div id="colunadireita">
		</div>
		<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div> 
	</div>
</body>
</html>
