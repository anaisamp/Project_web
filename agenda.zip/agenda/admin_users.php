<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 2) header('Location: ./index.php');

$_SESSION['pageid']=8;

$lista_utilizadores = $_SESSION['agenda']->getListaUtilizadores();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
	  
		<div id="headercontainer">
			<div id="banner"> </div>
				<div id="navbuttonsadmin">
					<a style="text-decoration:underline" class="navbutton" href="admin_users.php">Users</a>
					<a class="navbutton" href="admin_categories.php">Categories</a>
					<a class="navbutton" href="admin_sugestions.php">Suggestions</a>
					<a class="navbutton" href="admin_reclamations.php">Complaints</a>
					<a class="navbutton" href="settings.php">Settings</a>
					<a id="botao_logout" class="navbutton" href="scripts/logout.php">Logout</a>
				</div>
	
		</div>

		<div id="colunaesquerda">
			<div id="verticalnavbuttonsadmin">
			</div>
		</div>

		<div id="colunacentro">
		  <div id="listautilizadores">
				<table id="tabutilizadores" cellspacing="0">
				<h3 id="titulo">Users List<br />
				  <br />
				   <br />
				</h3>
				</caption>
					<thead class="style1" id="cabecalho_lista_utilizadores">
						<tr><td id="cabecalho_nome">Name</td><td id="cabecalho_username">Username</td><td id="cabecalho_email">Email</td>
						<td class="colunabranco"> </td><td class="colunabranco"> </td></tr>
					</thead>
					<tbody>
					
						<?php
						if(!isset($lista_utilizadores))
							echo "<tr><td>There are no users registered.</tr></td>";
						else
						{
							foreach($lista_utilizadores as $utilizador)
							{
								if(!$_SESSION['agenda']->userIsLocked($utilizador['cod_utilizador']))
									echo '<tr class="linha_utilizador"><td class="primeira_celula">' . $utilizador['nome'] . '</td><td>' . $utilizador['username'] . '</td><td><a class="maillink" href="mailto:' . $utilizador['email'] . '">'. $utilizador['email'] . '</td><td><a style="text-decoration:underline" href="scripts/operacao_admin.php?op=1&id='. $utilizador['cod_utilizador'].'"> Lock </a></td><td><a style="text-decoration:underline" href="scripts/operacao_admin.php?op=3&id='. $utilizador['cod_utilizador'].'"> Delete </a></td></tr>';
								else
									echo '<tr class="linha_utilizador"><td class="primeira_celula"><strike>'. $utilizador['nome'] . '</strike></td><td><strike>' . $utilizador['username'] . '</strike></td><td><a class="maillink" href="mailto:' . $utilizador['email'] .'"><strike>' . $utilizador['email'] . '</strike></a></td><td><a style="text-decoration:underline" href="scripts/operacao_admin.php?op=2&id='. $utilizador['cod_utilizador'].'"> Unlock </a></td><td><a style="text-decoration:underline" href="scripts/operacao_admin.php?op=3&id='. $utilizador['cod_utilizador'].'"> Delete </a></td></tr>';								
							}
						}
						?>
					</tbody>
				</table>
					
			</div>
		</div>
		<!--<div id="colunadireita"></div>-->
		<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div> 
	</div>
</body>
</html>
