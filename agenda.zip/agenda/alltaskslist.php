<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 1) header('Location: ./index.php');

if($_SESSION['pageid'] == 2)
{
	if(isset($_SESSION['nome'])) unset($_SESSION['nome']);
	if(isset($_SESSION['data'])) unset($_SESSION['data']);
	if(isset($_SESSION['categoria'])) unset($_SESSION['categoria']);
	if(isset($_SESSION['prioridade'])) unset($_SESSION['prioridade']);
    if(isset($_SESSION['intervenientes'])) unset($_SESSION['intervenientes']);
	if(isset($_SESSION['local']))  unset($_SESSION['local']);
	if(isset($_SESSION['url'])) unset($_SESSION['url']);
}


$_SESSION['pageid']=4;

$lista_tarefas = $_SESSION['agenda']->getListaTarefas();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
	  
		<div id="headercontainer">
			<div id="banner"> </div>
			
			<div id="navbuttons">
					<!--<a  class="navbutton" href="scripts/logout.php"><img id="logout" src="images/logout.png" /></a>-->
					
		</div >
		<div id="navbuttonSet">
			<a id="navbuttonSet" href="scripts/logout.php"> Logout</a>
			<a id="navbuttonSet" href="settings.php">Settings</a>
		</div><div id="navbuttonSetLeft">
			<a href="taskdetails.php">Add new task</a>
			<a> | </a>
			<a href="scripts/print_page.php?op=4">Print these tasks </a>
			</div>
 	 </div>



		<div id="colunaesquerda">
		
				 
			<div id="verticalnavbuttons">
								
				<a class="verticalnavbutton" href="dailytaskslist.php">Daily Tasks</a>
				<a class="verticalnavbutton" href="weeklytaskslist.php">Weekly Tasks</a>
				<a class="verticalnavbutton" href="monthlytaskslist.php">Monthly Tasks</a>
				<a class="verticalnavbutton"   id="pagina" href="alltaskslist.php">All Tasks</a>
			
				<!--<a class="verticalnavbutton" href="print.php">Print this tasks</a>-->

			</div>
			</div>
		<div id="colunatarefas">
						<div id="listatarefas">
						
					<table id="tabtarefas" cellspacing="0">
				<h3 id="tit" align="center"><br />
				  To-do List<br />
				  <br />
				 <br />
				</h3>

				

					<thead class="style1" id="cabecalho_lista_tarefas">

						<tr><td id="cabecalho_nome"></a>
	Name</td><td id="cabecalho_data">Date</td><td id="cabecalho_categoria">Category</td> 
					
						<td class="colunabranco"></td>
					 </tr>
					</thead>
					<tbody class="style1">
				
					
						<?php
						if(!isset($lista_tarefas))
							echo "<tr><td>There are no tasks.</tr></td>";
						else
						{
							foreach($lista_tarefas as $tarefa)
							{
								if(!$_SESSION['agenda']->isTaskConcluded($tarefa['cod_tarefa']))
									echo '<tr class="linha_tarefa"><td class="primeira_celula"><img class="priority" src="images/prioridade_' . $tarefa['prioridade_cod_prioridade'] .'.png"><a href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'">'. $tarefa['nome'] . '</a></td><td><a href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'">' . $tarefa['data_tarefa'] . '</a></td><td><a href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'">' . $_SESSION['agenda']->getDescCategoria($tarefa['categoria_cod_categoria']) . '</a></td><td><a href="taskdetails.php?id='. $tarefa['cod_tarefa'].'"><a class="myButton" href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'"><img id="lupa" src="images/lupa.png"/><a class="myButton" href="scripts/calendar_operation.php?op=4&id='. $tarefa['cod_tarefa'].'"><img id="lupa" src="images/check.png"/><a  class="myButton" href="scripts/calendar_operation.php?op=6&id='. $tarefa['cod_tarefa'].'"><img id="lupa" src="images/garbage.png"/></a></td></tr>';
								else
									echo '<tr class="linha_tarefa"><td class="primeira_celula"><img class="priority" src="images/prioridade_' . $tarefa['prioridade_cod_prioridade'] .'.png"><a href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'"><strike>'. $tarefa['nome'] . '</strike></a></td><td><a href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'"><strike>' . $tarefa['data_tarefa'] . '</strike></a></td><td><a href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'"><strike>' . $_SESSION['agenda']->getDescCategoria($tarefa['categoria_cod_categoria']) . '</strike></a></td><td><a href="taskdetails.php?id='. $tarefa['cod_tarefa'].'"><a class="myButton" href="taskdetails.php?id=' .$tarefa['cod_tarefa'] .'"><img id="lupa" src="images/lupa.png"/><a class="myButton" href="scripts/calendar_operation.php?op=5&id='. $tarefa['cod_tarefa'].'"><img id="lupa" src="images/check.png"/><a  class="myButton" href="scripts/calendar_operation.php?op=6&id='. $tarefa['cod_tarefa'].'"><img id="lupa" src="images/garbage.png"/></a></td></tr>';
							}
						}
						?>
					</tbody>
				

				</table>
								</div>
		</div>
		<div id="colunadireita">
		
		
			<div id="conteudocalendario">
			
			  <p>
			    <?php 
				echo $_SESSION['agenda']->getCompactCalendarWeekNumbers();
			?>
		        </p>
					  	</div>
		</div>
	<div class="style1"  id="rodape">Contact Us: <a id="link" href="sugestion.php"> Send a Suggestion </a> <span class="style6">  |</span> <a href="reclamation.php" id="link"> Send a Complaint </a > � 2012 Web Engineering. All rights reserved.</div> 

	</div>
</body>
</html>
