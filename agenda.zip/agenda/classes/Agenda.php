<?php
class Agenda
{
	private $db_connection;
	private $cod_utilizador_logado;
	private $gestao_utilizadores;
	private $gestao_tarefas;
	private $gestao_reclamacoes;
	private $gestao_sugestoes;
	private $calendario;
		
	public function __construct()
	{
		$this->db_connection = mysql_connect("localhost","root","");
		mysql_select_db("data",$this->db_connection);
		$this->gestao_utilizadores = new GestaoUtilizadores($this->db_connection);
		$this->cod_utilizador_logado=-1;
		$this->calendario = new ApointmentCalendar();
		$this->gestao_tarefas = new GestaoTarefas($this->db_connection);
		$this->gestao_reclamacoes = new GestaoReclamacoes($this->db_connection);
		$this->gestao_sugestoes = new GestaoSugestoes($this->db_connection);
	}
	
	public function adicionarUtilizador($nome,$email,$username,$password)
	{
		$this->gestao_utilizadores->adicionarUtilizador($nome,$email,$username,$password);
	}
	
	public function usernameExiste($username)
	{
		return $this->gestao_utilizadores->usernameExiste($username);
	}
	
	public function reconnect()
	{
		$this->db_connection = mysql_connect("localhost","root","");
		mysql_select_db("data",$this->db_connection);
	}
	
	public function loginValido($username,$password)
	{
		return $this->gestao_utilizadores->loginValido($username,$password);
	}
	
	public function login($username)
	{
		$this->cod_utilizador_logado = $this->gestao_utilizadores->getCodUtilizador($username);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);
	}
	
	public function logout()
	{
		$this->cod_utilizador_logado=-1;
	}
	
	public function isUserLogged()
	{
		return ($this->cod_utilizador_logado > -1);
	}
	
	public function getDay()
	{
		return $this->calendario->getDay();
	}
	
	public function getMonth()
	{
		return $this->calendario->getMonth();
	}
	
	public function getYear()
	{
		return $this->calendario->getYear();
	}
	
	public function getCompactCalendar()
	{
		return $this->calendario->getCompactCalendar();
	}
	
	public function getCompactCalendarWeekNumbers()
	{
		return $this->calendario->getCompactCalendarWeekNumbers();
	}
	
	public function getListaCategorias()
	{
		return $this->gestao_tarefas->getListaCategorias();
	}
	
	public function getListaPrioridades()
	{
		return $this->gestao_tarefas->getListaPrioridades();
	}
	
	public function adicionarTarefa($nome,$data,$categoria,$prioridade,$intervenientes,$local,$url)
	{
		$this->gestao_tarefas->adicionarTarefa($nome,$data,$categoria,$prioridade,$intervenientes,$local,$url,$this->cod_utilizador_logado);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);
	}
	
	public function actualizarTarefa($cod,$nome,$data,$categoria,$prioridade,$intervenientes,$local,$url)
	{
		$this->gestao_tarefas->actualizarTarefa($cod,$nome,$data,$categoria,$prioridade,$intervenientes,$local,$url);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);
	}
	
	public function getListaTarefasDiarias()
	{
		return $this->calendario->getListaTarefasDiarias();
	}
	
	public function getDescPrioridade($cod)
	{
		return $this->gestao_tarefas->getDescPrioridade($cod);
	}
	
	public function getDescCategoria($cod)
	{
		return $this->gestao_tarefas->getDescCategoria($cod);
	}
	
	public function getTaskName($cod)
	{
		return $this->gestao_tarefas->getTaskName($cod);
	}
	
	public function getTaskDate($cod)
	{
		return $this->gestao_tarefas->getTaskDate($cod);
	}
	
	public function getTaskCategory($cod)
	{
		return $this->gestao_tarefas->getTaskCategory($cod);
	}
	
	public function getTaskPriority($cod)
	{
		return $this->gestao_tarefas->getTaskPriority($cod);
	}
	
	public function getTaskIntervenients($cod)
	{
		return $this->gestao_tarefas->getTaskIntervenients($cod);
	}
	
	public function getTaskLocal($cod)
	{
		return $this->gestao_tarefas->getTaskLocal($cod);
	}

	public function getTaskURL($cod)
	{
		return $this->gestao_tarefas->getTaskURL($cod);
	}
	
	public function incMonth()
	{
		$this->calendario->incMonth();
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);

	}
	
	public function decMonth()
	{
		$this->calendario->decMonth();
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);
	}
	
	public function setDay($day)
	{
		$this->calendario->setDay($day);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);
	}
	
	public function setDate($day,$month,$year)
	{
		$this->calendario->setDay($day);
		$this->calendario->setMonth($month);
		$this->calendario->setYear($year);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);	
	}
	
	public function markFinished($cod_tarefa)
	{
		$this->gestao_tarefas->markFinished($cod_tarefa,$this->cod_utilizador_logado);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);	
	}
	
	public function markUnfinished($cod_tarefa)
	{
		$this->gestao_tarefas->markUnfinished($cod_tarefa,$this->cod_utilizador_logado);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);	
	}
	
	public function isTaskConcluded($cod)
	{
		return $this->gestao_tarefas->isTaskConcluded($cod);
	}
	
	public function deleteTask($cod_tarefa)
	{
		$this->gestao_tarefas->deleteTask($cod_tarefa,$this->cod_utilizador_logado);
		$lista_tarefas = $this->gestao_tarefas->getListaTarefasUtilizador($this->cod_utilizador_logado);
		$this->calendario->addTasks($lista_tarefas);
	}
	
	public function getListaTarefasMensais()
	{
		return $this->gestao_tarefas->getListaTarefasMensais($this->calendario->getMonth(),$this->calendario->getYear(),$this->cod_utilizador_logado);
	}
	
	public function getListaTarefas()
	{
		return $this->gestao_tarefas->getListaTarefas($this->cod_utilizador_logado);
	}
	
	public function adicionarReclamacao($assunto,$mensagem)
	{
		$this->gestao_reclamacoes->adicionarReclamacao($assunto,$mensagem,$this->cod_utilizador_logado);
	}
	
	public function adicionarSugestao($assunto,$mensagem)
	{
		$this->gestao_sugestoes->adicionarSugestao($assunto,$mensagem,$this->cod_utilizador_logado);
	}
	
	public function getNomeUtilizadorCod($cod)
	{
		return $this->gestao_utilizadores->getNomeUtilizador($cod);
	}
	
	public function getNomeUtilizador()
	{
		return $this->gestao_utilizadores->getNomeUtilizador($this->cod_utilizador_logado);
	}


	public function getEmailUtilizador()
	{
		return $this->gestao_utilizadores->getEmailUtilizador($this->cod_utilizador_logado);
	}
	
	public function getUsernameUtilizador()
	{
		return $this->gestao_utilizadores->getUsernameUtilizador($this->cod_utilizador_logado);
	}
	
	public function getPasswordUtilizador()
	{
		return $this->gestao_utilizadores->getPasswordUtilizador($this->cod_utilizador_logado);
	}
	
	public function actualizarDadosPessoais($nome,$email,$password)
	{
		$this->gestao_utilizadores->actualizarDadosPessoais($nome,$email,$password,$this->cod_utilizador_logado);
	}
	
	public function getNivelAcesso()
	{
		return $this->gestao_utilizadores->getNivelAcesso($this->cod_utilizador_logado);
	}
	
	public function getListaUtilizadores()
	{
		return $this->gestao_utilizadores->getListaUtilizadores();
	}

	public function userIsLocked($cod)
	{
		return $this->gestao_utilizadores->userIsLocked($cod);
	}
	
	public function lockUser($cod)
	{
		$this->gestao_utilizadores->lockUser($cod);
	}
	
	public function unlockUser($cod)
	{
		$this->gestao_utilizadores->unlockUser($cod);
	}
	
	public function deleteUser($cod)
	{
		$this->gestao_utilizadores->deleteUser($cod);
	}
	
	public function adicionarCategoria($categoria)
	{
		$this->gestao_tarefas->adicionarCategoria($categoria);
	}
	
	public function getListaSugestoes()
	{
		return $this->gestao_sugestoes->getListaSugestoes();
	}
	
	public function sugestaoJaLida($cod)
	{
		return $this->gestao_sugestoes->sugestaoJaLida($cod);
	}
	
	public function apagarSugestao($cod)
	{
		$this->gestao_sugestoes->apagarSugestao($cod);
	}
	
	public function getListaReclamacoes()
	{
		return $this->gestao_reclamacoes->getListaReclamacoes();
	}
	
	public function reclamacaoJaLida($cod)
	{
		return $this->gestao_reclamacoes->reclamacaoJaLida($cod);
	}
	
	public function apagarReclamacao($cod)
	{
		$this->gestao_reclamacoes->apagarReclamacao($cod);
	}
	
	public function getTituloReclamacao($cod)
	{
		return $this->gestao_reclamacoes->getTituloReclamacao($cod);
	}
	
	public function getMensagemReclamacao($cod)
	{
		return $this->gestao_reclamacoes->getMensagemReclamacao($cod);
	}
	
	public function getNomeUtilizadorReclamacao($cod)
	{
		return $this->gestao_reclamacoes->getNomeUtilizadorReclamacao($cod);
	}
	
	public function getEmailUtilizadorReclamacao($cod)
	{
		return $this->gestao_reclamacoes->getEmailUtilizadorReclamacao($cod);
	}

	public function marcarReclamacaoVista($cod)
	{
		$this->gestao_reclamacoes->marcarReclamacaoVista($cod);
	}
	
	
	public function getTituloSugestao($cod)
	{
		return $this->gestao_sugestoes->getTituloSugestao($cod);
	}

	public function getMensagemSugestao($cod)
	{
		return $this->gestao_sugestoes->getMensagemSugestao($cod);
	}
	
	public function getNomeUtilizadorSugestao($cod)
	{
		return $this->gestao_sugestoes->getNomeUtilizadorSugestao($cod);
	}
	
	public function getEmailUtilizadorSugestao($cod)
	{
		return $this->gestao_sugestoes->getEmailUtilizadorSugestao($cod);
	}
	
	public function marcarSugestaoVista($cod)
	{
		$this->gestao_sugestoes->marcarSugestaoVista($cod);
	}
	
	public function getListaTarefasSemanais($semana)
	{
		return $this->gestao_tarefas->getListaTarefasSemanais($semana,$this->calendario->getYear(),$this->cod_utilizador_logado);
	}
}


?>