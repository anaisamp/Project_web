<?php
class ApointmentCalendar
{
	private $day;
	private $month;
	private $year;
	private $tarefas;
	private $nr_tarefas;
	
	function __construct()
	{
		$this->day = date("d");
		$this->month = date("m");
		$this->year = date("Y");
		$this->nr_tarefas=0;
	}
	
	public function getDay()
	{
		return $this->day;
	}
	
	public function setDay($d)
	{
		$d++;
		$d--;
		if($d<10) $d='0'.$d;

		$this->day = $d;
	}
	
	public function getMonth()
	{
		return $this->month;
	}
	
	public function setMonth($m)
	{
		$m++;
		$m--;
		if($m<10) $m='0'.$m;

		$this->month = $m;
	}
	
	public function getYear()
	{
		return $this->year;
	}
	
	public function setYear($y)
	{
		$this->year = $y;
	}
	
	public function incDay()
	{
		$this->setDay($this->day+1);
		
		if($this->day > cal_days_in_month(CAL_GREGORIAN,$this->month,$this->year))
		{
			$this->incMonth();
			$this->setDay(1);
		}		
	}
	
	public function decDay()
	{
		$this->setDay($this->day-1);
		
		if($this->day < 1)
		{
			$this->decMonth();
			$this->day = cal_days_in_month(CAL_GREGORIAN,$this->month,$this->year);
		}
	}
	
	public function incMonth()
	{
		$this->setMonth($this->month+1);
		$this->setDay(1);
		
		if($this->month > 12)
		{
			$this->incYear();
			$this->setMonth(1);
		}
		

	}
	
	public function decMonth()
	{
		$this->month--;
		$this->setDay(1);
		
		if($this->month < 1)
		{
			$this->month=12;
			$this->decYear();
		}	
		
		if($this->month<10) $this->month='0'.$this->month;	
	}
	
	public function incYear()
	{
		$this->year++;
		$this->setDay(1);
	}
	
	public function decYear()
	{
		$this->year--;
		$this->setDay(1);
	}
	
	public function addTasks($tarefas)
	{
		$this->tarefas = null;
		$this->nr_tarefas=0;
		if(isset($tarefas))
		{
			foreach($tarefas as $tarefa)
			{
				$this->tarefas[$this->nr_tarefas]= $tarefa;
				$this->nr_tarefas++;
			}
		}		
	}
	
	public function getListaTarefasDiarias()
	{
		$i=0;

		$data_actual = $this->year . '-' . $this->month . '-'. $this->day;
	
		if(isset($this->tarefas))
		{
			foreach($this->tarefas as $tarefa)
			{
				if($tarefa['data_tarefa'] == $data_actual)
				{
					$array[$i] = $tarefa;
					$i++;
				}
			}
		}
		return $array;
	}
	
	public function getCompactCalendar()
	{
		$res= '<table id="calendario" cellspacing="0">
			<caption ><table id="titulo_calendario"><tr><td id="retroceder"><a href="scripts/calendar_operation.php?op=1" class="linkscalendario">�</a></td><td id="mes_ano">' . date("F",mktime(0,0,0,$this->month,$this->day,$this->year)) . ' - ' . $this->year . '</td><td id="avancar"><a href="scripts/calendar_operation.php?op=2" class="linkscalendario">�</a></td></tr></table></caption>
			<thead>
				<th class="diassemana">Mon</th><th class="diassemana">Tue</th><th class="diassemana">Wed</th><th class="diassemana">Thu</th><th class="diassemana">Fri</th><th class="diassemana">Sat</th><th class="diassemana">Sun</th>
			</thead>
			<tr>';
		
		$primeirodiames = $this->firstOfTheMonth($this->month,$this->year);
		$nr_linhas=0;
		for($j=1;$j < $primeirodiames;$j++)
		{
				$res = $res . '<td> </td>';
		}

		for($i=1;$i <= cal_days_in_month(CAL_GREGORIAN,$this->month,$this->year);$i++,$j++)
		{
			if($i<10)$k='0'.$i;
			else $k=$i;
			if($k == date("d") && $this->month == date("m") && $this->year == date("Y"))
			{
			 	$res = $res . '<td id="hoje"';

				if($this->haTarefas($k,$this->month,$this->year)) $res = $res . ' class="temtarefas"';
				$res = $res . '><a href="scripts/calendar_operation.php?op=3&day='. $i . '">' . $i . '</a></td>';
			}
			elseif($k == $this->day)
			{
				$res = $res . '<td id="diaseleccionado"';
				if($this->haTarefas($k,$this->month,$this->year)) $res = $res . ' class="temtarefas"';
				$res = $res . '><a href="scripts/calendar_operation.php?op=3&day='. $i . '">' . $i . '</a></td>';
			}
			elseif($this->haTarefas($k,$this->month,$this->year))
				$res = $res . '<td class="temtarefas"><a href="scripts/calendar_operation.php?op=3&day='. $i . '">' . $i . '</a></td>';
			else $res = $res . '<td><a href="scripts/calendar_operation.php?op=3&day='. $i . '">'. $i . '</a></td>';
			
			if($j%7 == 0)
			{
			 	$res = $res . '</tr><tr>';
				$nr_linhas++;
			}
		}
		
		while($nr_linhas<6)
		{
			$res = $res . '<td> &nbsp;</td>';
			
			if($j%7 == 0)
			{
			 	$res = $res . '</tr><tr>';
				$nr_linhas++;
			}
			$j++;
		}
		
		$res = $res . '</tr></table>';
		
		return $res;
	}

	public function getCompactCalendarWeekNumbers()
	{
		$res= '<table id="calendario" cellspacing="0">
			<caption ><table id="titulo_calendario"><tr><td id="retroceder"><a href="scripts/calendar_operation.php?op=1" class="linkscalendario">�</a></td><td id="mes_ano">' . date("F",mktime(0,0,0,$this->month,$this->day,$this->year)) . ' - ' . $this->year . '</td><td id="avancar"><a href="scripts/calendar_operation.php?op=2" class="linkscalendario">�</a></td></tr></table></caption>
			<thead>
				<th> </th><th class="diassemana">Mon</th><th class="diassemana">Tue</th><th class="diassemana">Wed</th><th class="diassemana">Thu</th><th class="diassemana">Fri</th><th class="diassemana">Sat</th><th class="diassemana">Sun</th>
			</thead>
			<tr>';
		
		$primeirodiames = $this->firstOfTheMonth($this->month,$this->year);
		$nr_linhas=0;
		$res = $res . '<td class="numero_semana"><a href="weeklytaskslist.php?week=' . date("W", mktime(0, 0, 0, $this->month, 1, $this->year)) . '">' .date("W", mktime(0, 0, 0, $this->month, 1, $this->year)) . '</a></td>';
		for($j=1;$j < $primeirodiames;$j++)
		{
				$res = $res . '<td> </td>';
		}

		if($primeirodiames==1) $escrever = 0;
		else $escrever = 1;
		
		for($i=1;$i <= cal_days_in_month(CAL_GREGORIAN,$this->month,$this->year);$i++,$j++)
		{
			if(($j-1)%7 == 0 && $escrever)
				$res = $res . '<td class="numero_semana"><a href="weeklytaskslist.php?week=' . date("W", mktime(0, 0, 0, $this->month, $i, $this->year)) . '">' .date("W", mktime(0, 0, 0, $this->month, $i, $this->year)) . '</a></td>';

			$escrever=1;			
			if($i<10)$k='0'.$i;
			else $k=$i;
			if($k == date("d") && $this->month == date("m") && $this->year == date("Y"))
			{
			 	$res = $res . '<td id="hoje"';

				if($this->haTarefas($k,$this->month,$this->year)) $res = $res . ' class="temtarefas"';
				$res = $res . '><a href="scripts/calendar_operation.php?op=3&day='. $i . '">' . $i . '</a></td>';
			}
			elseif($k == $this->day)
			{
				$res = $res . '<td id="diaseleccionado"';
				if($this->haTarefas($k,$this->month,$this->year)) $res = $res . ' class="temtarefas"';
				$res = $res . '><a href="scripts/calendar_operation.php?op=3&day='. $i . '">' . $i . '</a></td>';
			}
			elseif($this->haTarefas($k,$this->month,$this->year))
				$res = $res . '<td class="temtarefas"><a href="scripts/calendar_operation.php?op=3&day='. $i . '">' . $i . '</a></td>';
			else $res = $res . '<td><a href="scripts/calendar_operation.php?op=3&day='. $i . '">'. $i . '</a></td>';
			
			if($j%7 == 0)
			{
			 	$res = $res . '</tr><tr>';
				$nr_linhas++;
			}
		}

		if(($j-1)%7 == 0)
		{
			$res = $res . '<td class="numero_semana"></td>';
		}


		while($nr_linhas<6)
		{
			$res = $res . '<td> &nbsp;</td>';
		
			if($j%7 == 0)
			{
		 		$res = $res . '</tr><tr><td class="numero_semana"></td>';
				$nr_linhas++;
			}
			$j++;
		}

		
		$res = $res . '</tr></table>';
		
		return $res;
	}



	private function firstOfTheMonth($month,$year)
	{
		$primeirodia = date("w",mktime(0,0,0,$month,1,$year));
		if($primeirodia==0) $primeirodia=7;
		return $primeirodia;
	}
	
	private function haTarefas($day,$month,$year)
	{
		if(isset($this->tarefas))
		{
			foreach($this->tarefas as $tarefa)
			{
				if($tarefa['data_tarefa'] == $year . '-' . $month . '-' . $day)return 1;
			}
		}
		return 0;
	}
}

?>