<?
class GestaoReclamacoes
{
	
	private $db_connection;
	
	public function __construct($dbc)
	{
		$this->db_connection = $dbc;
	}
	
	public function adicionarReclamacao($assunto,$mensagem,$cod_utilizador)
	{
		mysql_query("INSERT INTO reclamacao (titulo,mensagem,ja_vista,user_cod_utilizador) VALUES ('". $assunto ."','". $mensagem . "',b'0'," . $cod_utilizador . ")");
	}
	
	public function getListaReclamacoes()
	{
		$res = mysql_query("SELECT * FROM reclamacao");
		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}
	
	public function reclamacaoJaLida($cod)
	{
		$res = mysql_query("SELECT * FROM reclamacao WHERE cod_reclamacao=" . $cod . " AND ja_vista=b'1'");
		
		if(mysql_num_rows($res) == 1) return 1;
		return 0;
	}
	
	public function apagarReclamacao($cod)
	{
		mysql_query("DELETE FROM reclamacao WHERE cod_reclamacao=" . $cod);
	}
	
	public function getTituloReclamacao($cod)
	{
		$res = mysql_query("SELECT reclamacao.titulo FROM reclamacao WHERE cod_reclamacao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['titulo'];
	}
	
	public function getMensagemReclamacao($cod)
	{
		$res = mysql_query("SELECT reclamacao.mensagem FROM reclamacao WHERE cod_reclamacao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['mensagem'];
	}
	
	public function getNomeUtilizadorReclamacao($cod)
	{

		$res = mysql_query("SELECT user.nome FROM user,reclamacao WHERE cod_utilizador=reclamacao.user_cod_utilizador AND reclamacao.cod_reclamacao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['nome'];
	}	
	
	public function getEmailUtilizadorReclamacao($cod)
	{
		$res = mysql_query("SELECT user.email FROM user,reclamacao WHERE cod_utilizador=reclamacao.user_cod_utilizador AND reclamacao.cod_reclamacao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['email'];
	}
	
	public function marcarReclamacaoVista($cod)
	{
		mysql_query("UPDATE reclamacao SET ja_vista=b'1' WHERE cod_reclamacao=". $cod);
	}
}
?>