<?
class GestaoSugestoes
{
	
	private $db_connection;
	
	public function __construct($dbc)
	{
		$this->db_connection = $dbc;
	}
	
	public function adicionarSugestao($assunto,$mensagem,$cod_utilizador)
	{
		mysql_query("INSERT INTO sugestao (titulo,mensagem,ja_vista,user_cod_utilizador) VALUES ('". $assunto ."','". $mensagem . "',b'0'," . $cod_utilizador . ")");
	}
	
	public function getListaSugestoes()
	{
		$res = mysql_query("SELECT * FROM sugestao");
		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}
	
	public function sugestaoJaLida($cod)
	{
		$res = mysql_query("SELECT * FROM sugestao WHERE cod_sugestao=" . $cod . " AND ja_vista=b'1'");
		
		if(mysql_num_rows($res) == 1) return 1;
		return 0;
	}
	
	public function apagarSugestao($cod)
	{
		mysql_query("DELETE FROM sugestao WHERE cod_sugestao=" . $cod);
	}
	
		public function getTituloSugestao($cod)
	{
		$res = mysql_query("SELECT sugestao.titulo FROM sugestao WHERE cod_sugestao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['titulo'];
	}
	
	public function getMensagemSugestao($cod)
	{
		$res = mysql_query("SELECT sugestao.mensagem FROM sugestao WHERE cod_sugestao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['mensagem'];
	}
	
	public function getNomeUtilizadorSugestao($cod)
	{

		$res = mysql_query("SELECT user.nome FROM user,sugestao WHERE cod_utilizador=sugestao.user_cod_utilizador AND sugestao.cod_sugestao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['nome'];
	}	
	
	public function getEmailUtilizadorSugestao($cod)
	{
		$res = mysql_query("SELECT user.email FROM user,sugestao WHERE cod_utilizador=sugestao.user_cod_utilizador AND sugestao.cod_sugestao=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['email'];
	}
	
	public function marcarSugestaoVista($cod)
	{
		mysql_query("UPDATE sugestao SET ja_vista=b'1' WHERE cod_sugestao=". $cod);
	}
	
}
?>