<?
class GestaoTarefas
{
	
	private $db_connection;
	
	public function __construct($dbc)
	{
		$this->db_connection = $dbc;
	}
	
	public function getListaCategorias()
	{
		$res = mysql_query("SELECT * FROM categoria");
		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}
	
	public function getListaPrioridades()
	{
		$res = mysql_query("SELECT * FROM prioridade");
		$i=0;
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;		
		}
		return $array;
	}
	
	public function adicionarTarefa($nome,$data,$categoria,$prioridade,$intervenientes,$local,$url,$cod_utilizador)
	{
		mysql_query("INSERT INTO tarefas (nome,local,data_tarefa,intervenientes,url,concluida,prioridade_cod_prioridade,categoria_cod_categoria,user_cod_utilizador) VALUES ('". $nome ."','". $local . "','" . $data . "','" . $intervenientes . "','" . $url . "',b'0'," .$prioridade ."," . $categoria . "," . $cod_utilizador .")");
	}
	
	public function actualizarTarefa($cod,$nome,$data,$categoria,$prioridade,$intervenientes,$local,$url)
	{
		mysql_query("UPDATE tarefas SET nome='". $nome ."',local='". $local . "',data_tarefa='" . $data . "',intervenientes='" . $intervenientes . "',url='" . $url . "',prioridade_cod_prioridade=" .$prioridade .",categoria_cod_categoria=" . $categoria . " WHERE cod_tarefa=". $cod);
	}
		
	public function getListaTarefasUtilizador($cod_utilizador)
	{
		$res = mysql_query("SELECT * FROM tarefas WHERE user_cod_utilizador=" . $cod_utilizador);
		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}
	
	public function getDescPrioridade($cod)
	{
		$res = mysql_query("SELECT descricao FROM prioridade WHERE cod_prioridade=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['descricao'];
	}

	public function getDescCategoria($cod)
	{
		$res = mysql_query("SELECT descricao FROM categoria WHERE cod_categoria=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['descricao'];
	}

	public function getTaskName($cod)
	{
		$res = mysql_query("SELECT nome FROM tarefas WHERE cod_tarefa=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['nome'];
	}

	public function getTaskDate($cod)
	{
		$res = mysql_query("SELECT data_tarefa FROM tarefas WHERE cod_tarefa=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['data_tarefa'];
	}
	
	public function getTaskIntervenients($cod)
	{
		$res = mysql_query("SELECT intervenientes FROM tarefas WHERE cod_tarefa=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['intervenientes'];
	}

	public function getTaskCategory($cod)
	{
		$res = mysql_query("SELECT categoria_cod_categoria FROM tarefas WHERE cod_tarefa=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['categoria_cod_categoria'];
	}
	
	public function getTaskPriority($cod)
	{
		$res = mysql_query("SELECT prioridade_cod_prioridade FROM tarefas WHERE cod_tarefa=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['prioridade_cod_prioridade'];
	}

	public function getTaskLocal($cod)
	{
		$res = mysql_query("SELECT local FROM tarefas WHERE cod_tarefa=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['local'];
	}
	
	public function getTaskURL($cod)
	{
		$res = mysql_query("SELECT url FROM tarefas WHERE cod_tarefa=" . $cod);
		$row = mysql_fetch_array($res);
		return $row['url'];
	}
	
	public function markFinished($cod_tarefa,$cod_utilizador)
	{
		mysql_query("UPDATE tarefas SET concluida=b'1' WHERE cod_tarefa=". $cod_tarefa . ' AND user_cod_utilizador=' . $cod_utilizador);
	}
	
	public function markUnfinished($cod_tarefa,$cod_utilizador)
	{
		mysql_query("UPDATE tarefas SET concluida=b'0' WHERE cod_tarefa=". $cod_tarefa . ' AND user_cod_utilizador=' . $cod_utilizador);
	}
	
	public function isTaskConcluded($cod)
	{
		$res = mysql_query("SELECT * FROM tarefas WHERE cod_tarefa=" . $cod . " AND concluida=b'1'");
		
		if(mysql_num_rows($res) == 1) return 1;
		return 0;
	}
	
	public function deleteTask($cod_tarefa,$cod_utilizador)
	{
		mysql_query("DELETE FROM tarefas WHERE cod_tarefa=" . $cod_tarefa . ' AND user_cod_utilizador =' . $cod_utilizador);
	}
	
	public function getListaTarefasMensais($mes,$ano,$cod_utilizador)
	{
		$res = mysql_query("SELECT * FROM tarefas WHERE MONTH(tarefas.data_tarefa)=" . $mes . " AND YEAR(tarefas.data_tarefa)=" . $ano . " AND user_cod_utilizador=" . $cod_utilizador);
		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}
	
	public function getListaTarefas($cod_utilizador)
	{
		$res = mysql_query("SELECT * FROM tarefas WHERE user_cod_utilizador=" . $cod_utilizador. " ORDER BY data_tarefa ASC");
		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}
	
	public function getListaTarefasSemanais($semana,$ano,$cod_utilizador)
	{
	
		$data_inicio = $this->week_start_date($semana-1, $ano);

		$data_fim = date('Y-m-d', strtotime('+6 days', strtotime($data_inicio)));

		$res = mysql_query("SELECT * FROM tarefas WHERE user_cod_utilizador=" . $cod_utilizador. " AND data_tarefa BETWEEN '". $data_inicio ."' AND '" . $data_fim . "' ORDER BY data_tarefa ASC");
		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}

	
	public function adicionarCategoria($categoria)
	{
		mysql_query("INSERT INTO categoria (descricao) VALUES ('". $categoria ."')");
	}
	
	private function week_start_date($wk_num, $yr, $first = 1, $format = 'Y-m-d')
	{
     	$wk_ts  = strtotime('+' . $wk_num . ' weeks', strtotime($yr . '0101'));
	 	$mon_ts = strtotime('-' . date('w', $wk_ts) + $first . ' days', $wk_ts);
	 	return date($format, $mon_ts);
	}
}
?>