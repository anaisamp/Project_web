<?
class GestaoUtilizadores
{
	
	private $db_connection;
	
	public function __construct($dbc)
	{
		$this->db_connection = $dbc;
	}
	
	public function adicionarUtilizador($nome,$email,$username,$password)
	{
		 mysql_query("INSERT INTO user (nome,email,username,password,nivel_acesso) VALUES ('". $nome ."','". $email . "','" . $username ."','" . $password ."',1)");
	}
	
	public function usernameExiste($username)
	{
		$res = mysql_query("SELECT * FROM user WHERE username='" . $username . "'");
		
		if(mysql_num_rows($res) > 0) return 1;
		return 0;
	}
	
	public function loginValido($username,$password)
	{
		$res = mysql_query("SELECT * FROM user WHERE username='" . $username . "' AND BINARY password='" . $password ."' AND desactivado=b'0'");

		if(mysql_num_rows($res) == 1) return 1;
		return 0;
	}
	
	public function getCodUtilizador($username)
	{
		$res = mysql_query("SELECT user.cod_utilizador FROM user WHERE username='" . $username . "'");
		
		$linha = mysql_fetch_array($res);
		return 	$linha['cod_utilizador'];
	}	
	
	public function getNomeUtilizador($cod)
	{
		$res = mysql_query("SELECT user.nome FROM user WHERE cod_utilizador=" . $cod);
		
		$linha = mysql_fetch_array($res);
		return 	$linha['nome'];
	}
	
	public function getEmailUtilizador($cod)
	{
		$res = mysql_query("SELECT user.email FROM user WHERE cod_utilizador=" . $cod . "");
		
		$linha = mysql_fetch_array($res);
		return 	$linha['email'];
	}
	
	public function getUsernameUtilizador($cod)
	{
		$res = mysql_query("SELECT user.username FROM user WHERE cod_utilizador=" . $cod . "");
		
		$linha = mysql_fetch_array($res);
		return 	$linha['username'];
	}
	
	public function getPasswordUtilizador($cod)
	{
		$res = mysql_query("SELECT user.password FROM user WHERE cod_utilizador=" . $cod );
		
		$linha = mysql_fetch_array($res);
		return 	$linha['password'];
	}
	
	public function actualizarDadosPessoais($nome,$email,$password,$cod)
	{
		mysql_query("UPDATE user SET nome='". $nome ."',email='". $email . "',password='" . $password . "' WHERE cod_utilizador=". $cod);
	}
	
	public function getNivelAcesso($cod)
	{
		$res = mysql_query("SELECT user.nivel_acesso FROM user WHERE cod_utilizador=" . $cod);
		$linha = mysql_fetch_array($res);

		return 	$linha['nivel_acesso'];
	}
	
	public function getListaUtilizadores()
	{
		$res = mysql_query("SELECT cod_utilizador,nome,username,email FROM user WHERE nivel_acesso!=2");

		$i=0;
		
		while($row = mysql_fetch_array($res))
		{
			$array[$i] = $row;
			$i++;
		}
		return $array;
	}
	
	public function userIsLocked($cod)
	{
		$res = mysql_query("SELECT * FROM user WHERE cod_utilizador=" . $cod . " AND desactivado=b'1'");
		
		if(mysql_num_rows($res) == 1) return 1;
		return 0;
	}
	
	public function lockUser($cod)
	{
		mysql_query("UPDATE user SET desactivado=b'1' WHERE cod_utilizador=". $cod);
	}

	public function unlockUser($cod)
	{
		mysql_query("UPDATE user SET desactivado=b'0' WHERE cod_utilizador=". $cod);
	}
	
	public function deleteUser($cod)
	{
		mysql_query("DELETE FROM user WHERE cod_utilizador=" . $cod);
	}

}

?>