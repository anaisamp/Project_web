<?php 
include './classes/ApointmentCalendar.php'; 
$calendario = new ApointmentCalendar();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
		<div id="banner">
		<h1> Aqui fica o Banner</h1>
		</div>
		<div id="colunaesquerda">
		N�o sei o que � para por aqui, para j� tem o logout, mas pode ser mudado para outro lado qualquer.<br />
		<a href="scripts/logout.php">Logout</a>
		</div>
		<div id="colunacentro">
		<a href="weeklytasksdiagram.php">Weekly</a> <a href="">Monthly</a>
		<h2 id="titulo">Today's Tasks:  <?php echo $calendario->getDay() . '-' . $calendario->getMonth() . '-' . $calendario->getYear(); ?></h2>
			<a href="dailytaskslist.php">List</a>
				<table id="tabdiaria" cellspacing="0">
					<thead>
						<tr>
								<th style="min-width:150px">Tasks</th><th>00:00</th><th>01:00</th><th>02:00</th><th>03:00</th><th>04:00</th><th>05:00</th><th>06:00</th><th>07:00</th><th>08:00</th><th>09:00</th><th>10:00</th><th>11:00</th><th>12:00</th><th>13:00</th><th>14:00</th><th>15:00</th><th>16:00</th><th>17:00</th><th>18:00</th><th>19:00</th><th>20:00</th><th>21:00</th><th>22:00</th><th>23:00</th>
							
						</tr>
					</thead>
					<tbody>
						<tr>
							<td style="border-color:black">
							Relat�rio do Projecto Integrado
							</td>
							<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td style="background-color:darkblue;border-color:darkblue;"></td><td></td><td></td><td></td><td></td><td></td><td></td>
						</tr>

						<tr>
							<td style="background-color:lightgrey;border-color:black;">
							<s>Redigir Introdu��o<s>
							</td>
							<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td style="background-color:lightgrey;border-color:lightgrey;"></td><td style="background-color:lightgrey;border-color:lightgrey;"></td><td style="background-color:lightgrey;border-color:lightgrey;"></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
						</tr>
						<tr>
							<td style="border-color:black">
							Modelo de Dom�nio
							</td>
							<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td style="background-color:lightblue;border-color:lightblue;"><td style="background-color:lightblue;border-color:lightblue;"></td><td></td><td></td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
						</tr>
						<tr>
							<td style="border-color:black">
							Mostrar ao Professor para pedir opini�o
							</td>
							<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td style="background-color:lightgreen"></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
						</tr>
						<tr>
							<td style="border-color:black">
							Diagrama de Use Cases
							</td>
							<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td style="background-color:red;border-color:red;"></td><td style="background-color:red;border-color:red;"></td><td style="background-color:red;border-color:red;"></td><td></td><td></td><td></td><td></td><td></td><td></td>
						</tr>
					</tbody>
				</table>

		</div>
		<div id="colunadireita">
			<div id="conteudocalendario">
			<?php 
				echo $calendario->showCompactCalendar();
			?>
			</div>
		</div>
		<div id="rodape">
			Aqui fica a informa��o acerca de direitos de autor, browsers recomendados bla bla bla.
		</div>
	</div>
</body>
</html>
