<?php
session_start();

function __autoload($class_name)
{
	require_once("classes/" . $class_name.".php");
}

if(!isset($_SESSION['agenda']))
	$_SESSION['agenda'] = new Agenda();
else
	$_SESSION['agenda']->reconnect();

if($_SESSION['agenda']->isUserLogged())
{
	if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged())
	{

		$nivel_acesso = $_SESSION['agenda']->getNivelAcesso();
	
		switch($nivel_acesso)
		{
			case 1: header('Location: ../dailytaskslist.php');break;
			case 2: header('Location: ../admin_users.php');break;
		}
	}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>


</head>

<body>
	<div id="corpo">
			<div id="banner"> </div>
			<div id="welcome"> Welcome! </div>
		
		<div id="conteudoadicional"> 

			<img src="images/prom1.png"/>
		</div>
		
		<div id="colunasignin">

		
		  <div id="containerlogin">
			
			<h3 class="style5">Sign in</h3>	
			<br />
				<form id="formlogin" action="scripts/login.php" method="post">
				
					<div align="left">
					  <p><span class="style4">Username</span><br />
			            <input name="username" type="text" id="user" value="" />
			            <br />
				        <span class="style4">Password</span><br />
				        <input type="password" name="password"id="pass" />
				        <br />
				        <input type="submit" value="Sign in" id="botao_login"/>
				        <br/>
						<br/>
						<br/>
						<br/>
					</div>
				</form>
				
				<span class="style1">New around here?</span><br />
			    <a href="register.php" class="style4" id="linkcriarconta">Create an Account</a></div>
				 
				 <?php if($_SESSION['erros']['login_invalido']) echo '<span class="campo_invalido">Invalid login.</span>';?>
	  </div>
		<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div>
</div>
</body>
</html>
