<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 1) header('Location: ./index.php');

if(!isset($_SESSION['prevpage']))
	$_SESSION['prevpage']=$_SESSION['pageid'];
	
if($_SESSION['pageid'] == 2)
{
	if(isset($_SESSION['nome'])) unset($_SESSION['nome']);
	if(isset($_SESSION['data'])) unset($_SESSION['data']);
	if(isset($_SESSION['categoria'])) unset($_SESSION['categoria']);
	if(isset($_SESSION['prioridade'])) unset($_SESSION['prioridade']);
    if(isset($_SESSION['intervenientes'])) unset($_SESSION['intervenientes']);
	if(isset($_SESSION['local']))  unset($_SESSION['local']);
	if(isset($_SESSION['url'])) unset($_SESSION['url']);
}	
	
$_SESSION['pageid']=5;

$class_assunto = $class_mensagem = "normal";

if($_SESSION['erros']['assunto']) $class_assunto = "campo_invalido";
if($_SESSION['erros']['mensagem']) $class_mensagem = "campo_invalido";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
		<div id="headercontainer">
			<div id="banner"> </div>
			
			
					<div id="navbuttons">
					
		</div >
		<div id="navbuttonSet">
					<a id="navbuttonSet" href="scripts/logout.php">Logout</a>
					<a id="navbuttonSet" href="settings.php">Settings</a>
					<a id="navbuttonSet" href="dailytaskslist.php">See my Tasks</a>
				</div>
				

			
		</div>
		<div id="colunaesquerda">
		</div>
		<div id="colunacentro">
		<h2 id="titulo">Submit Complaint </h2>
		<p>&nbsp;</p>
		<form action="scripts/adicionar_reclamacao.php" id="formregistoreclamacao" method="post">
				<span class="<?php echo $class_assunto; ?>">Subject *<br /></span><input name="assunto" type="text" class="tema" value="<?php echo $_SESSION['assunto'] ?>" size="40"/><br/></span>
						<span class="<?php echo $class_mensagem; ?>">Message *<br /></span>
	
			<textarea class="message" name="mensagem" cols="40" rows="10"><?php echo $_SESSION['assunto'] ?></textarea>
				<span class="style1">(*) Required </span> <br/><br/>
				<!--<input name="mensagem" type="text" value="<?php echo $_SESSION['assunto'] ?>" /><br />-->
				<input name="submit" type="submit" value="Submit" />
				
		  </form>
		<br />			<?php if($_SESSION['erros']['mensagem']) echo '<span class="campo_invalido">Please write a message.</span>'; ?>
				<br /><?php if($_SESSION['erros']['assunto']) echo '<span class="campo_invalido">Please write a subject.</span>'; ?><br />


		<br />
						</div>
		<div id="colunadireita">
		</div>
		<div class="style1"  id="rodape">Contact Us: <a id="link" href="sugestion.php"> Send a Suggestion </a> <span class="style6">  |</span> <a href="reclamation.php" id="link"> Send a Complaint </a > � 2012 Web Engineering. All rights reserved.</div> 

	</div>
</body>
</html>
