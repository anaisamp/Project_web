<?php
	session_start();

	function __autoload($class_name)
	{
		require_once("classes/" . $class_name.".php");
	}
	
	if(!isset($_SESSION['agenda']))
		$_SESSION['agenda'] = new Agenda();	
	else
		$_SESSION['agenda']	->reconnect();
	
	$class_nome = $class_email = $class_username = $class_password = $class_confirmacaopass = "normal";

	if($_SESSION['erros']['nome']) $class_nome = "campo_invalido";
	if($_SESSION['erros']['email']) $class_email = "campo_invalido";
	if($_SESSION['erros']['username']) $class_username = "campo_invalido";
	if($_SESSION['erros']['password']) $class_password = "campo_invalido";
	if($_SESSION['erros']['confirmacaopass']) $class_confirmacaopass = "campo_invalido";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>

</head>

<body>
	<div id="corpo">
		<div id="headercontainer">
			<div id="banner">
				<!--	<a></a>
				<div id="navbuttons">
				</div>-->
			</div>
		</div>
		<div id="colunaesquerda"> </div>
		
		<div id="colunacentro">
			<blockquote>
			  <h2 class="style5">Create Account</h2>
			  <p class="style5">&nbsp;</p>
			</blockquote>
		  
			<form id="formregisto" action="scripts/adicionar_utilizador.php" method="post">
			  <div class="style4">
			    <p><span class="<?php echo $class_nome; ?>">Name</span></p>
				  <p>
				    <input name="nome" type="text" class="inputr" value="<?php echo $_SESSION['nome'] ?>"/>
				    <br />
			        <span class="<?php echo $class_email; ?>">E-mail</span>
				  </p>
				  <p>
				    <input name="email" type="text" class="inputr" value="<?php echo $_SESSION['email'] ?>" />
				    <br/>
			      <span class="<?php echo $class_username; ?>">Username</span></p>
				  <p>
				    <input name="username" type="text" class="inputr"  value="<?php echo $_SESSION['username'] ?>" />
				    <br/>
			      		<span class="<?php echo $class_password; ?>">Password</span>
					</p>
				  <p>
				    <input name="password" type="password" class="inputr"   />
				    <br />
			      	<span class="<?php echo $class_confirmacaopass;?>">Confirmation</span>
				  </p>
				  <p>
				    <input name="confirmacaopass" type="password" class="inputr"   />
			      </p>
				  <p>&nbsp;</p>
				  <p>
					  	<input name="submit" type="submit" class="style4" id="bRegist" value="Submit" />
						<a class="cancel" href="scripts/home.php">Cancel</a></br>

				  </p>
			  </div>
			</form>
		    <p>
				<br />
			  	<br />
		      	<br />
              	<?php if($_SESSION['erros']['nome']) echo '<span class="campo_invalido">Please submit a valid name.</span>'; ?>
		      	<br />
              	<?php if($_SESSION['erros']['email']) echo '<span class="campo_invalido">Please submit a valid email.</span>'; ?>
		      	<br />
              	<?php if($_SESSION['erros']['username'] == 1) echo '<span class="campo_invalido">Please submit a username.</span>'; ?>
		      	<br />
              	<?php if($_SESSION['erros']['username'] == 2) echo '<span class="campo_invalido">This username is already being used.</span>'; ?>
		      	<br />
              	<?php if($_SESSION['erros']['password'] == 1) echo '<span class="campo_invalido">The password must have at least five characters.</span>'; ?>
		      	<br />
              	<?php if($_SESSION['erros']['password'] == 2) echo '<span class="campo_invalido">The password and confirmation fields do not match.</span>'; ?>
		      	<br />
          	</p>
      </div>
		
		<!--<div id="colunadireita">	</div>-->
		<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div>
	</div>
	
</body>
</html>
