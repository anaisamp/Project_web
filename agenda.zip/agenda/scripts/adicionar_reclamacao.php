<?php
session_start();

function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ../index.php');

$_SESSION['agenda']->reconnect();

$_SESSION['assunto'] = $_POST['assunto'];
$_SESSION['mensagem'] = $_POST['mensagem'];


unset($_SESSION['erros']);


$erro=0;

if(strlen($_POST['assunto']) == 0)
{
	$_SESSION['erros']['assunto']=1;
	$erro=1;
}

if(strlen($_POST['assunto']) == 0)
{
	$_SESSION['erros']['mensagem']=1;
	$erro=1;
}


if($erro) header('Location: ../reclamation.php');

else
{
	$_SESSION['agenda']->adicionarReclamacao($_SESSION['assunto'],$_SESSION['mensagem']);

	unset($_SESSION['assunto']);
	unset($_SESSION['mensagem']);
	header('Location: ../success.php');
}
?>