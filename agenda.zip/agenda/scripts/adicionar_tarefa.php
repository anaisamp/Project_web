<?php
session_start();

function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	

if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ../index.php');

$_SESSION['agenda']->reconnect();
$_SESSION['nome'] = $_POST['nome'];
$_SESSION['data'] = $_POST['data'];
$_SESSION['categoria'] = $_POST['categoria'];
$_SESSION['prioridade'] = $_POST['prioridade'];
$_SESSION['intervenientes'] = $_POST['intervenientes'];
$_SESSION['local'] = $_POST['local'];
$_SESSION['url']=$_POST['url'];
unset($_SESSION['erros']);

function dataValida($date)
{
  //match the format of the date
  if (preg_match ("/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/", $date, $parts))
  {
    //check weather the date is valid of not
        if(checkdate($parts[2],$parts[3],$parts[1]))
          return true;
        else
         return false;
  }
  else
    return false;
}

if($_SESSION['url'] == "http://")
{
	$_SESSION['url']="";
	$_POST['url']="";
}

function urlValido($url)
{
	return preg_match('|^http(s)?://[a-z0-9-]+(.[a-z0-9-]+)*(:[0-9]+)?(/.*)?$|i', $url);
}

$erro=0;

if(strlen($_POST['nome']) == 0)
{
	$_SESSION['erros']['nome']=1;
	$erro=1;
}

if(!dataValida($_POST['data']))
{
	$_SESSION['erros']['data']=1;
	$erro=1;
}
	
if(strlen($_POST['url']) > 0 && !urlValido($_POST['url']))
{
	$_SESSION['erros']['url']=1;	
	$erro=1;
}
 

if($erro) header('Location: ../taskdetails.php');
elseif(!isset($_SESSION['cod_tarefa']))
{
	$_SESSION['agenda']->adicionarTarefa($_SESSION['nome'],$_SESSION['data'],$_SESSION['categoria'],$_SESSION['prioridade'],$_SESSION['intervenientes'],$_SESSION['local'],$_SESSION['url']);

	unset($_SESSION['nome']);
	unset($_SESSION['data']);
	unset($_SESSION['categoria']);
	unset($_SESSION['prioridade']);
	unset($_SESSION['intervenientes']);
	unset($_SESSION['local']);
	unset($_SESSION['url']);

	$pag = $_SESSION['prevpage'];
	unset($_SESSION['prevpage']);
	switch($pag)
	{
		case 1: header('Location: ../dailytaskslist.php');break;
		case 2: header('Location: ../taskdetails.php');break;
		case 3: header('Location: ../monthlytaskslist.php');break;
		case 4: header('Location: ../alltaskslist.php');break;
		case 13: header('Location: ../weeklytaskslist.php');break;
	}
}
else
{
	$_SESSION['agenda']->actualizarTarefa($_SESSION['cod_tarefa'],$_SESSION['nome'],$_SESSION['data'],$_SESSION['categoria'],$_SESSION['prioridade'],$_SESSION['intervenientes'],$_SESSION['local'],$_SESSION['url']);
	unset($_SESSION['cod_tarefa']);
	unset($_SESSION['nome']);
	unset($_SESSION['data']);
	unset($_SESSION['categoria']);
	unset($_SESSION['prioridade']);
	unset($_SESSION['intervenientes']);
	unset($_SESSION['local']);
	unset($_SESSION['url']);

	$pag = $_SESSION['prevpage'];
	unset($_SESSION['prevpage']);
	
	switch($pag)
	{
		case 1: header('Location: ../dailytaskslist.php');break;
		case 2: header('Location: ../taskdetails.php');break;
		case 3: header('Location: ../monthlytaskslist.php');break;
		case 4: header('Location: ../alltaskslist.php');break;
		case 13: header('Location: ../weeklytaskslist.php');break;
	}
}

?>