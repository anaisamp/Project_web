<?php
session_start();

function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	

if(!isset($_SESSION['agenda'])) header('Location: ../register.php');

$_SESSION['agenda']->reconnect();
$_SESSION['nome'] = $_POST['nome'];
$_SESSION['email'] = $_POST['email'];
$_SESSION['username'] = $_POST['username'];
$_SESSION['password'] = $_POST['password'];
unset($_SESSION['erros']);

function emailValido($email){
	//return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
	return preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/i",$email);
}

$erro=0;

if(strlen($_POST['nome']) == 0)
{
	$_SESSION['erros']['nome']=1;
	$erro=1;
}

if(!emailValido($_POST['email']))
{
	$_SESSION['erros']['email']=1;
	$erro=1;
}
	
if(strlen($_POST['username'])==0)
{
	$_SESSION['erros']['username']=1;	
	$erro=1;
}

elseif($_SESSION['agenda']->usernameExiste($_POST['username']))
{
	$_SESSION['erros']['username']=2;
	$erro=1;
}

if(strlen($_POST['password']) < 5)
{ 
	$_SESSION['erros']['password']=1;
	$erro=1;
}

if($_POST['password'] != $_POST['confirmacaopass'])
{
	$_SESSION['erros']['password']=2;
	$_SESSION['erros']['confirmacaopass']=1;
	$erro=1;
}
 

if($erro) header('Location: ../register.php');
else
{
	$_SESSION['agenda']->adicionarUtilizador($_SESSION['nome'],$_SESSION['email'],$_SESSION['username'],$_SESSION['password']);
	unset($_SESSION['nome']);
	unset($_SESSION['email']);
	unset($_SESSION['username']);
	header('Location: ../welcome.php');
}

?>