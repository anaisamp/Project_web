<?php
session_start();

function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	

if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged() || !isset($_GET['op'])) header('Location: ../index.php');

$_SESSION['agenda']->reconnect();

switch($_GET['op'])
{
	case 1: $_SESSION['agenda']->decMonth();break;
	case 2:	$_SESSION['agenda']->incMonth();break;
	case 3: $_SESSION['agenda']->setDay($_GET['day']);break;
	case 4: $_SESSION['agenda']->markFinished($_GET['id']);break;
	case 5: $_SESSION['agenda']->markUnfinished($_GET['id']);break;
	case 6: $_SESSION['agenda']->deleteTask($_GET['id']);break;
	case 7: $_SESSION['agenda']->seeTask($_GET['id']);break;
	default:break;
}

switch($_SESSION['pageid'])
{
	case 1: header('Location: ../dailytaskslist.php');break;
	case 2: header('Location: ../taskdetails.php');break;
	case 3: 
			if($_GET['op']==3) 
				header('Location: ../dailytaskslist.php');
			else
				header('Location: ../monthlytaskslist.php');
			break;
	case 4: 
			if($_GET['op']==3) 
				header('Location: ../dailytaskslist.php');
			else
				header('Location: ../alltaskslist.php');
			break;
	case 13:
			if($_GET['op']==3) 
				header('Location: ../dailytaskslist.php');
			else
	 			header('Location: ../weeklytaskslist.php');
			break;
}
?>
