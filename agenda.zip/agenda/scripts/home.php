<?php
	session_start();
	if(isset($_SESSION['nome'])) unset($_SESSION['nome']);
	if(isset($_SESSION['email'])) unset($_SESSION['email']);
	if(isset($_SESSION['username'])) unset($_SESSION['username']);
	if(isset($_SESSION['password'])) unset($_SESSION['password']);
	if(isset($_SESSION['confirmacaopass'])) unset($_SESSION['confirmacaopass']);
	if(isset($_SESSION['erros'])) unset($_SESSION['erros']);

	header('Location: ../index.php');
?>