<?php
session_start();

function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	

if(!isset($_SESSION['agenda'])) header('Location: ../index.php');

$_SESSION['agenda']->reconnect();

if($_SESSION['agenda']->loginValido($_POST['username'],$_POST['password']))
{
	$_SESSION['agenda']->login($_POST['username']);
	unset($_SESSION['erros']);
	
	$nivel_acesso = $_SESSION['agenda']->getNivelAcesso();
	
	switch($nivel_acesso)
	{
		case 1: header('Location: ../dailytaskslist.php');break;
		case 2: header('Location: ../admin_users.php');break;
	}
}
else
{
	$_SESSION['erros']['login_invalido']=1;
	header('Location: ../index.php');
}
?>