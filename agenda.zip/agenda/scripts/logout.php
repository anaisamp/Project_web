<?php
session_start();

function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	

if(!isset($_SESSION['agenda'])) header('Location: ../index.php');

$_SESSION['agenda']->reconnect();

$_SESSION['agenda']->logout();
session_destroy();
header('Location: ../index.php');
?>