<?php
session_start();

function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	

if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged() || !isset($_GET['op'])) header('Location: ../index.php');

$_SESSION['agenda']->reconnect();

switch($_GET['op'])
{
	case 1: $_SESSION['agenda']->lockUser($_GET['id']);break;
	case 2:	$_SESSION['agenda']->unlockUser($_GET['id']);break;
	case 3: $_SESSION['agenda']->deleteUser($_GET['id']);break;
	case 4:
			if(strlen($_POST['categoria'])>0) $_SESSION['agenda']->adicionarCategoria($_POST['categoria']);
			header('Location: ../admin_categories.php');break;
	case 5: $_SESSION['agenda']->apagarSugestao($_GET['id']);break;
	case 6: $_SESSION['agenda']->apagarReclamacao($_GET['id']);break;
	case 7: $_SESSION['agenda']->marcarSugestaoVista($_GET['id']);
			header('Location: ../admin_sugestions.php');
			break;
	case 8: $_SESSION['agenda']->marcarReclamacaoVista($_GET['id']);
			header('Location: ../admin_reclamations.php');break;
			break;			
	default:break;
}

switch($_SESSION['pageid'])
{
	case 8: header('Location: ../admin_users.php');break;
	case 10: header('Location: ../admin_sugestions.php');break;
	case 11: header('Location: ../admin_reclamations.php');break;
	default:break;
}
?>