<?php 
session_start();
ob_start();
function __autoload($class_name)
{
	require_once("../classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged() || !isset($_GET['op'])) header('Location: ../index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 1) header('Location: ../index.php');

switch($_GET['op'])
{
	case 1:$lista_tarefas = $_SESSION['agenda']->getListaTarefasDiarias();break;
	case 2:$lista_tarefas = $_SESSION['agenda']->getListaTarefasSemanais($_GET['week']);break;
	case 3:$lista_tarefas = $_SESSION['agenda']->getListaTarefasMensais();break;
	case 4:$lista_tarefas = $_SESSION['agenda']->getListaTarefas();
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- <link rel="stylesheet" type="text/css" href="./styles/styles.css" /> -->
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>

<script type="text/javascript">

  window.print()

</script>

<div id="corpo">
	  
	<div id="colunatarefas">
		<div id="listatarefas">
              <h3 id="tit">Tasks List</h3>
				<hr />
                <?php
					if(!isset($lista_tarefas))
							echo "There are no tasks.<hr />";
					else
					{
						foreach($lista_tarefas as $tarefa)
						{
							if(!$_SESSION['agenda']->isTaskConcluded($tarefa['cod_tarefa']))
							{
								echo '<b>Name: </b>' . $tarefa['nome'] . '<br />';
								echo '<b>Date: </b>' . $tarefa['data_tarefa'] . '<br />';
								echo '<b>Priority: </b>' . $_SESSION['agenda']->getDescPrioridade($tarefa['prioridade_cod_prioridade']) . '<br />';
								if(strlen($tarefa['local'])>0) echo '<b>Local: </b>' . $tarefa['local'] . '<br />';
								if(strlen($tarefa['intervenientes'])>0) echo '<b>Intervenients: </b>' . $tarefa['intervenientes'] . '<br />';
								if(strlen($tarefa['url'])>0) echo '<b>URL: </b>' . $tarefa['url'] . '<br />';
								echo '<hr />'; 
							}
						}
					}
				?>
		</div>
	</div>
	<div class="style1" id="rodape">
		� 2012 Web Engineering. All rights reserved.
	</div>
	
	<?php
/*
	switch($_GET['op'])
	{
		case 1:header('Location: ../dailytaskslist.php');break;
		case 2:header('Location: ../weeklytaskslist.php');break;
		case 3:header('Location: ../monthlytaskslist.php');break;
		case 4:header('Location: ../alltaskslist.php');break;
	}
*/
	?>
</div>
</body>
</html>
