<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();

if(!isset($_SESSION['prevpage']))
	$_SESSION['prevpage']=$_SESSION['pageid'];
	
if($_SESSION['pageid'] == 2)
{
	if(isset($_SESSION['nome'])) unset($_SESSION['nome']);
	if(isset($_SESSION['data'])) unset($_SESSION['data']);
	if(isset($_SESSION['categoria'])) unset($_SESSION['categoria']);
	if(isset($_SESSION['prioridade'])) unset($_SESSION['prioridade']);
    if(isset($_SESSION['intervenientes'])) unset($_SESSION['intervenientes']);
	if(isset($_SESSION['local']))  unset($_SESSION['local']);
	if(isset($_SESSION['url'])) unset($_SESSION['url']);
}

	
$_SESSION['pageid']=7;

	$class_nome = $class_email = $class_username = $class_password = $class_confirmacaopass = "normal";

	if($_SESSION['erros']['nome']) $class_nome = "campo_invalido";
	if($_SESSION['erros']['email']) $class_email = "campo_invalido";
	if($_SESSION['erros']['username']) $class_username = "campo_invalido";
	if($_SESSION['erros']['password']) $class_password = "campo_invalido";
	if($_SESSION['erros']['confirmacaopass']) $class_confirmation = "campo_invalido";
	
	if(isset($_SESSION['nome']) || isset($_SESSION['email'])|| isset($_SESSION['password']) || isset($_SESSION['confirmacaopass']))
	{
		$nome = $_SESSION['nome'];
		$email = $_SESSION['email'];
		$password =	$_SESSION['password'];
	}
	
	else
	{
		$nome = $_SESSION['agenda']->getNomeUtilizador();
		$email = $_SESSION['agenda']->getEmailUtilizador();
		$password = $_SESSION['agenda']->getPasswordUtilizador();
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>

</head>

<body>
	<div id="corpo">
		<div id="headercontainer">
			<div id="banner">
			</div>
			
				<?php if($_SESSION['agenda']->getNivelAcesso() == 1)
				echo'
				
	
		<div id="navbuttonSet">
					<a id="navbuttonSet" href="scripts/logout.php">Logout</a>
		
					<a id="navbuttonSet" href="dailytaskslist.php">See my Tasks</a>
				</div>
				

			

			';
				elseif($_SESSION['agenda']->getNivelAcesso() == 2)
				echo'
				<div id="navbuttonsadmin">
					<a class="navbutton" href="admin_users.php">Users</a>
					<a class="navbutton" href="admin_categories.php">Categories</a>
					<a class="navbutton" href="admin_sugestions.php">Suggestions</a>
					<a class="navbutton" href="admin_reclamations.php">Complaints</a>
					<a style="text-decoration:underline" class="navbutton" href="settings.php">Settings</a>
					<a id="botao_logout" class="navbutton" href="scripts/logout.php">Logout</a>
				</div>';
				?>
				
			<br/>
		</div>
		<div id="colunaesquerda"></div> 
		<div id="colunacentro">
			<h3 id="titulo">Set Account</h3>
			<p class="style5">&nbsp;</p>
			<p class="style5">&nbsp;</p>
			<form action="scripts/actualizar_dados_pessoais.php" method="post" class="style4" id="formsettings">
				<div align="left" class="style1">
				  <p class="style4">Name</p>
				  <p class="style4">
				    <input name="nome" type="text" class="input" value="<?php echo $nome; ?>" size="40"/>
			      </p>
				  <p class="style4"><br />
			        <span class="<?php echo $class_email; ?>">E-mail</span></p>
				  <p class="style4">
				    <input name="email" type="text" class="input"  value="<?php echo $email; ?>" size="40" />
			      </p>
				  <p class="style4"><br />
			        <span class="<?php echo $class_password; ?>">Password</span></p>
				  <p class="style4">
				    <input name="password" type="password" class="input"  value="<?php echo $password; ?>" size="40"/>
			      </p>
				  <p class="style4"><br />
			        <span class="<?php echo $class_confirmacaopass;?>">Confirmation</span></p>
				  <p class="style4">
				    <input name="confirmacaopass" type="password"class="input"  value="<?php echo $password; ?>" size="40"/>
			      </p>
				  <p class="style4">&nbsp;</p>
				  <p>
				    <input type="submit" value="Submit" id=settingsubmit"/>			
			          </p>
			  </div>
		  </form>
		<br />
		<?php if($_SESSION['erros']['nome']) echo '<span class="campo_invalido">Please submit a valid name.</span>'; ?>
		<br />
		<?php if($_SESSION['erros']['email']) echo '<span class="campo_invalido">Please submit a valid email.</span>'; ?><br />
		<?php if($_SESSION['erros']['password'] == 1) echo '<span class="campo_invalido">The password must have at least five characters.</span>'; ?>
		<?php if($_SESSION['erros']['password'] == 2) echo '<span class="campo_invalido">The password and confirmation fields do not match.</span>'; ?>
		<br />
		</div>
		
		<div id="colunadireita">	
		</div>
			<div class="style1"  id="rodape"> � 2012 Web Engineering. All rights reserved.</div> 

	</div>
	
</body>
</html>
