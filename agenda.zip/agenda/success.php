<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
<div id="corpo">
		<div id="headercontainer">
			<div id="banner"> </div>
				<div id="navbuttonSet">
					<a id="navbuttonSet" href="scripts/logout.php"> Logout</a>
			<a id="navbuttonSet" href="settings.php">Settings</a>
				<a id="navbuttonSet" href="dailytaskslist.php"> See my Tasks</a>
		</div>
		
		<!--<div id="colunaesquerda">		</div>-->
		<div id="colunacentro">
		  <h2 id="titulo">&nbsp;</h2>
		  <h2>&nbsp;</h2>
		  <blockquote>
		    <h2 align="center">Success!</h2>
	      </blockquote>
		  <p>
			  <?php 
				$pag = $_SESSION['prevpage'];
				unset($_SESSION['prevpage']);
				switch($pag)
				{
					case 1: $link = "dailytaskslist.php";break;
					case 2: $link = "taskdetails.php";break;
					case 3: $link = "monthlytaskslist.php";break;
					case 4: $link = "alltaskslist.php";break;
					default: $link = "dailytaskslist.php";
				}
			?>
		  </p>
			<p>&nbsp;</p>
			<p>&nbsp;</p>
			<form action="<?php echo $link ;?>">
			  <p align="right"><span class="style1">Your message was successfully sent.</span>		</p>
			  <blockquote>
			    <p>&nbsp;</p>
			    <p>&nbsp;</p>
			    <p align="center">
			      <input name="submit" type="submit" value="Ok"/>
	            </p>
			    <p align="center">&nbsp;</p>
		      </blockquote>
			</form>
  </div>
		
		<!--<div id="colunadireita">		</div>-->
	<div class="style1" id="rodape">
			� 2012 Web Engineering. All rights reserved.
	</div>
</div>
</body>
</html>
