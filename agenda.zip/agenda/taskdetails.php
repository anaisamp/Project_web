<?php 
session_start();

function __autoload($class_name)
{
	require_once("./classes/" . $class_name.".php");
}
	
if(!isset($_SESSION['agenda']) || !$_SESSION['agenda']->isUserLogged()) header('Location: ./index.php');

$_SESSION['agenda']->reconnect();
if($_SESSION['agenda']->getNivelAcesso() != 1) header('Location: ./index.php');

if(!isset($_SESSION['prevpage']))
	$_SESSION['prevpage']=$_SESSION['pageid'];
	
$_SESSION['pageid']=2;


if(isset($_GET['id']))
{
$_SESSION['cod_tarefa']=$_GET['id'];
$_SESSION['nome'] = $_SESSION['agenda']->getTaskName($_GET['id']);
$_SESSION['data'] = $_SESSION['agenda']->getTaskDate($_GET['id']);
$_SESSION['categoria'] = $_SESSION['agenda']->getTaskCategory($_GET['id']);
$_SESSION['prioridade'] = $_SESSION['agenda']->getTaskPriority($_GET['id']);
$_SESSION['intervenientes'] = $_SESSION['agenda']->getTaskIntervenients($_GET['id']);
$_SESSION['local'] = $_SESSION['agenda']->getTaskLocal($_GET['id']);
$_SESSION['url']= $_SESSION['agenda']->getTaskURL($_GET['id']);
}
else
{
$_SESSION['url']= "http://";
}

$lista_categorias = $_SESSION['agenda']->getListaCategorias();
$lista_prioridades = $_SESSION['agenda']->getListaPrioridades();

$class_nome = $class_data = $ $class_url  = "normal";

if($_SESSION['erros']['nome']) $class_nome = "campo_invalido";
if($_SESSION['erros']['data']) $class_data = "campo_invalido";
if($_SESSION['erros']['url']) $class_url = "campo_invalido";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
		<div id="headercontainer">
			<div id="banner">  </div>
				

				
				<div id="navbuttonSet">
					<a id="navbuttonSet" href="scripts/logout.php"> Logout</a>
			<a id="navbuttonSet" href="settings.php">Settings</a>
				<a id="navbuttonSet" href="dailytaskslist.php"> See my Tasks</a>
		</div><div id="navbuttonSetLeft">
	
			</div>

 	 </div>
		
		<div id="colunaesquerda">
			<!--<div id="verticalnavbuttons">
				<a class="verticalnavbutton" href="dailytaskslist.php">Daily Tasks</a>
				<a class="verticalnavbutton" href="weeklytaskslist.php">Weekly Tasks</a>
				<a class="verticalnavbutton" href="monthlytaskslist.php">Monthly Tasks</a>
				<a class="verticalnavbutton" href="alltaskslist.php">All Tasks</a>
			</div>-->
	  </div>
		<div id="colunacentro">
		  <h2 id="titulo">Task Details</h2>
		  <p>&nbsp;</p>
	    <form action="scripts/adicionar_tarefa.php" id="formregistotarefa" method="post">
			<div align="left">
			  <p><span class="style4">Name</span></p>
				  <p><span class="style4">
			      <input name="nome" type="text" class="input" value="<?php echo $_SESSION['nome'] ?>" size="30"/>
				    <br />
				    <span>Date</span></span></p>
				  <p><span class="style4">
			      <input name="data" type="text"  class="input" value="<?php if(!isset($_SESSION['data'])) echo $_SESSION['agenda']->getYear() . '-' . $_SESSION['agenda']->getMonth() . '-' . $_SESSION['agenda']->getDay(); else echo $_SESSION['data'];?>" size="30" />
			      <br />
			      Category
				    </span></p>
		  <p><span class="style4">
				    <select name="categoria"  class="input" >
				      <?php
						foreach($lista_categorias as $categoria)
						{
							echo '<option value="'. $categoria['cod_categoria'] . '"';
							if($categoria['cod_categoria'] == $_SESSION['categoria']) echo ' selected="selected" ';
							echo '>' . $categoria['descricao'] . '</option>';
						}
					?>
		            </select>
		          <br />
			      Priority</span></p>
				  <p><span class="style4">
			      <select name="prioridade"  class="input" >
			        <?php
						foreach($lista_prioridades as $prioridade)
						{
							echo '<option value="'. $prioridade['cod_prioridade'] . '"';
							if($prioridade['cod_prioridade'] == $_SESSION['prioridade']) echo ' selected="selected" ';
							echo '>' . $prioridade['descricao'] . '</option>';
						}	
					?>
		              </select>
	              <br />
			      Intervenients</span></p>
				  <p><span class="style4">
			      <input name="intervenientes" type="text"  class="input" value="<?php echo $_SESSION['intervenientes']; ?>" size="30" />
		          <br />
			      Local </span></p>
				  <p><span class="style4">
			      <input name="local" type="text"  class="input"  value="<?php echo $_SESSION['local']; ?>" size="30" />
		          <br />
		          <span >URL</span></span></p>
				  <p><span class="style4"><span >
			      <input name="url" type="text" class="input"  value="<?php echo $_SESSION['url']; ?>" size="30" />
                                                                            </span></span></p>
				  <p><span class="style4"><br />
			      </span>
				    <input type="submit" value="Save"/>
			      </p>
		  </div>
			</form>
		<br />
		<br />
		<?php if($_SESSION['erros']['nome']) echo '<span class="campo_invalido">Please submit a valid name.</span>'; ?><br />
		<?php if($_SESSION['erros']['data']) echo '<span class="campo_invalido">Please submit a valid date.</span>'; ?><br />
		<?php if($_SESSION['erros']['url'] == 1) echo '<span class="campo_invalido">Please submit a valid url.</span>'; ?><br />
	  </div>
		<div id="colunadireita">
			<div id="conteudocalendario">
			<?php 
				echo $_SESSION['agenda']->getCompactCalendarWeekNumbers();
			?>
			</div>
		</div>
			<div class="style1"  id="rodape">Contact Us: <a id="link" href="sugestion.php"> Send a Suggestion </a> <span class="style6">  |</span> <a href="reclamation.php" id="link"> Send a Complaint </a > � 2012 Web Engineering. All rights reserved.</div> 		</div>
</body>
</html>
