<?php
//include('./classes/ApointmentCalendar.php');
session_start();
function __autoload($class_name)
{
	require_once("classes/" . $class_name.".php");
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body>
<?php
//	if(!isset($_SESSION['agenda']))
//		$_SESSION['agenda'] = new Agenda();
//	else $_SESSION['agenda']->reconnect();

//$lista_categorias = $_SESSION['agenda']->getListaCategorias();

/*
$db_connection = mysql_connect("localhost","root","");
	mysql_select_db("data",$db_connection);

$agenda= new Agenda;
$agenda->login("admin");

if($agenda->reclamacaoJaLida(3)) echo "ja lida";
else echo "nao lida";
$agenda->marcarReclamacaoVista(3);
if($agenda->reclamacaoJaLida(3)) echo "ja lida";
else echo "nao lida";
*/

//echo "Week: " . date("W", mktime(0, 0, 0, 1, 1, 2012));

/*
$week_number = 40; 
$year = 2008; 
for($day=1; $day<=7; $day++)  
	echo date('m/d/Y', strtotime($year."W".$week_number.$day))."<br />"; 
*/
/*
$agenda= new Agenda;
$agenda->login("andre");

echo "Week: " . date("W", mktime(0, 0, 0, $agenda->getMonth(), $agenda->getDay(), $agenda->getYear()));
*/

function week_start_date($wk_num, $yr, $first = 1, $format = 'Y-m-d')
{
     $wk_ts  = strtotime('+' . $wk_num . ' weeks', strtotime($yr . '0101'));
	 $mon_ts = strtotime('-' . date('w', $wk_ts) + $first . ' days', $wk_ts);
	 return date($format, $mon_ts);
}
$week_number = 52;
$year = 2012;
$sStartDate = week_start_date($week_number, $year);
$sEndDate   = date('Y-m-d', strtotime('+6 days', strtotime($sStartDate)));
echo 'Week: ' . $week_number . '<br />';
echo 'Start Date: ' . $sStartDate . '<br />';
echo 'End Date: ' . $sEndDate . '<br />';

/*
$tarefas=$agenda->getListaTarefasSemanais(3);

foreach($tarefas as $tarefa)
	echo "Cod: " . $tarefa['cod_tarefa'] . " Nome: " . $tarefa['nome'] . " Local: " . $tarefa['local'] . " Data: " . $tarefa['data_tarefa'];
	*/
/*
echo $agenda->isTaskConcluded(36).'<br />';
$agenda->markFinished(36);
echo $agenda->isTaskConcluded(36).'<br />';
$agenda->markUnfinished(36);
echo $agenda->isTaskConcluded(36).'<br />';
$agenda->markFinished(36);
echo $agenda->isTaskConcluded(36).'<br />';
*/

/*	else
	{
		switch($_GET['op'])
		{
			case	1:$_SESSION['calendar']->decYear();break;
			case	2:$_SESSION['calendar']->decMonth();break;
			case	3:$_SESSION['calendar']->decDay();break;
			case	4:$_SESSION['calendar']->incDay();break;
			case	5:$_SESSION['calendar']->incMonth();break;
			case	6:$_SESSION['calendar']->incYear();break;
		}
		
	}
		
	echo $_SESSION['calendar']->showCompactCalendar();
	echo "<br />" . "dia: " . $_SESSION['calendar']->getDay();
	echo "<br />" . "m�s: " . $_SESSION['calendar']->getMonth();
	echo "<br />" . "ano: " . $_SESSION['calendar']->getYear();
	
*/
	
/*
	$_SESSION['calendar']->decYear();
	echo '<br><br>';
	echo $_SESSION['calendar']->showCompactCalendar();
	
	$_SESSION['calendar']->incMonth();
	echo '<br><br>';
	$_SESSION['calendar']->showCompactCalendar();

	$_SESSION['calendar']->decDay();
	echo '<br><br>';
	$_SESSION['calendar']->showCompactCalendar();
*/
/*
$_SESSION['agenda'] = new Agenda();

if($_SESSION['agenda']->usernameExiste("andre")) echo "existe";
else echo "nao existe";

*/



?>
<!--
<a href="unittest.php?op=1">Y-</a> 
<a href="unittest.php?op=2">M-</a> 
<a href="unittest.php?op=3">D-</a> 
<a href="unittest.php?op=4">D+</a> 
<a href="unittest.php?op=5">M+</a> 
<a href="unittest.php?op=6">Y+</a>
-->
</body>
</html>
