<?php 
include './classes/ApointmentCalendar.php'; 
$calendario = new ApointmentCalendar();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
</head>

<body>
	<div id="corpo">
		<div id="banner">
		<h1> Aqui fica o Banner</h1>
		</div>
		<div id="colunaesquerda">
		N�o sei o que � para por aqui, para j� tem o logout, mas pode ser mudado para outro lado qualquer.<br />
		<a href="scripts/logout.php">Logout</a>
		</div>
		<div id="colunacentro">
		<a href="dailytasksdiagram.php">Daily</a> <a href="">Monthly</a>
		<h2 id="titulo">This Week's Tasks:  <?php echo $calendario->getDay() . '-' . $calendario->getMonth() . '-' . $calendario->getYear(); ?></h2>
			<a href="weeklytaskslist.php">List</a>
				<table id="tabsemanal" cellspacing="0">
					<thead>
							<tr>
								<th colspan="8">May</th>
							</tr>
							<tr>
								<th  colspan="8">Week 19</th>
							</tr>
							<tr>
								<th><br />Tasks</th><th>Mon<br />5</th><th>Tue<br />6</th><th>Wed<br />7</th><th>Thu<br />8</th><th>Fri<br />9</th><th>Sat<br />10</th><th>Sun<br />11</th>
							</tr>
						
					</thead>
					<tbody>
						<tr>
							<td style="border-color:black">
							Relat�rio do Projecto Integrado
							</td>
							<td style="background-color:darkblue;border-right-color:darkblue;"></td><td style="background-color:darkblue;border-right-color:darkblue;border-left-color:darkblue;"></td><td></td><td></td><td></td><td></td>
						</tr>
						<tr>
							<td style="background-color:lightgrey;border-color:black;">
							<s>Redigir Introdu��o</s>
							</td>
							<td></td><td></td><td style="background-color:lightgrey;border-right-color:lightgrey;"></td><td style="background-color:lightgrey;border-right-color:lightgrey;"></td><td style="background-color:lightgrey"></td><td></td><td>
						</tr>
						<tr>
							<td style="border-color:black">
							Modelo de Dom�nio
							</td>
							<td></td><td></td><td></td><td style="background-color:lightblue;border-right-color:lightblue;"><td style="background-color:lightblue;"></td><td></td><td></td>
						</tr>
						<tr>
							<td style="border-color:black">
							Mostrar ao Professor para pedir opini�o
							</td>
							<td></td><td></td><td></td><td style="background-color:lightgreen;"></td><td></td><td></td><td></td>
						</tr>
						<tr>
							<td style="border-color:black">
							Diagrama de Use Cases
							</td>
							<td></td><td></td><td></td><td></td><td style="background-color:red;border-right-color:red;"></td><td style="background-color:red;border-right-color:red;"></td><td style="background-color:red"></td>
						</tr>



					</tbody> 	
				</table>

		</div>
		<div id="colunadireita">
			<div id="conteudocalendario">
			<?php 
				echo $calendario->showCompactCalendar();
			?>
			</div>
		</div>
		<div id="rodape">
			� 2012 Web Engineering. All rights reserved.
		</div>
	</div>
</body>
</html>
