<?php
	session_start();

	function __autoload($class_name)
	{
		require_once("classes/" . $class_name.".php");
	}
	
	if(!isset($_SESSION['agenda']))
		$_SESSION['agenda'] = new Agenda();	
	else
		$_SESSION['agenda']	->reconnect();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="./styles/styles.css" />
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Agenda</title>
<style type="text/css">
<!--
.style6 {color: #333333}
-->
</style>
</head>

<body>
	<div id="corpo">
		<div id="banner">
			
		</div>
		<div id="colunaesquerda"></div>
		<div id="colunacentro">
			<h2 id="titulo">Success!</h2>
			<p class="style7">&nbsp;</p>
			<p class="style7">&nbsp;</p>
			<p class="style7">&nbsp;</p>
			<form action="index.php">
			  <blockquote>
			    <p><span class="style1">Your account has been created successfully.</span></p>
				<p><span class="style1">Start rigth now planning your to-do list.</span></p>
		      </blockquote>
			  <blockquote>
			    <p><br />
			      
			      <input type="submit" value="Start Now"/> 
		          <span class="style1">Thanks for joining in!</span></p>
		      </blockquote>
			</form>
		</div>
		
		<div id="colunadireita">
		</div>
		<div class="style1" id="rodape">
			<p>� 2012 Web Engineering. All rights reserved.</p>
		</div>
	</div>
	
</body>
</html>
